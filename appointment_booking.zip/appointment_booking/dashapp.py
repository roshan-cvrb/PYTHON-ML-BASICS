# dashapp.py - Updated with Enhanced Model Tracking
import dash
from dash import dcc, html, Input, Output, State, callback_context, ALL
import dash_bootstrap_components as dbc
import sys
import os
from datetime import datetime, time
import logging
import webbrowser
import sqlite3
import json

# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from graph import create_graph, run_graph_sync
from utils.database import load_appointments
from utils.llm import get_llm
# UPDATED IMPORTS - Use SDK approach
from tracing.trace_collector import should_flush_trace, flush_trace, get_active_trace_id, configure_tracing_server, check_tracing_server

# === INTEGRATED LOGGING SETUP ===
def setup_logging():
    """Setup logging configuration and create necessary directories"""
    log_dirs = [
        "logs",
        "logs/sessions",
        "traces",
        "data"
    ]

    for log_dir in log_dirs:
        os.makedirs(log_dir, exist_ok=True)

    log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

    file_handler = logging.FileHandler(f'logs/app_{datetime.now().strftime("%Y%m%d")}.log')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter(log_format))

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter(log_format))

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    loggers = [
        'dashapp', 'main',
        'supervisor_agent', 'availability_agent',
        'confirmation_agent', 'cancellation_agent',
        'trace_collector', 'database'
    ]

    for logger_name in loggers:
        logger = logging.getLogger(logger_name)
        handler = logging.FileHandler(f'logs/{logger_name}.log')
        handler.setFormatter(logging.Formatter(log_format))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)

    print("✅ Logging setup completed")

# Initialize logging
setup_logging()
logger = logging.getLogger(__name__)

# CONFIGURE SDK TO USE FASTAPI SERVER
TRACING_SERVER_URL = os.getenv("TRACING_SERVER_URL", "http://localhost:8000")
configure_tracing_server(TRACING_SERVER_URL)

# Check if tracing server is available
if not check_tracing_server():
    logger.warning("⚠️ Tracing server not available. Traces will be lost.")
else:
    logger.info("✅ Tracing SDK connected to server")

logger.info("Enhanced Appointment Chat & Health Dashboard initialized")

# Initialize graph
graph = create_graph()

# Available models with enhanced tracking
GROQ_MODELS = [
    {'label': 'LLaMA 3.3 70B (Recommended)', 'value': 'llama-3.3-70b-versatile'},
    {'label': 'DeepSeek R1 Distill 70B', 'value': 'deepseek-r1-distill-llama-70b'},
    {'label': 'LLaMA 3.1 70B', 'value': 'llama-3.1-70b-versatile'},
    {'label': 'GPT OSS 120B', 'value': 'gpt-oss-120b'},
    {'label': 'LLaMA 3 70B', 'value': 'llama3-70b-8192'},
    {'label': 'LLaMA 3 8B', 'value': 'llama3-8b-8192'},
    {'label': 'Mixtral 8x7B', 'value': 'mixtral-8x7b-32768'},
    {'label': 'Gemma 7B', 'value': 'gemma-7b-it'},
    {'label': 'Gemma 2 9B', 'value': 'gemma2-9b-it'}
]

# Database helper functions for domains and timeslots
def init_domain_db():
    """Initialize domain and timeslot tables"""
    try:
        conn = sqlite3.connect('domainandslot.db')
        cursor = conn.cursor()
        
        # Create domains table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS domains (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create timeslots table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS timeslots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain_id INTEGER,
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (domain_id) REFERENCES domains (id)
            )
        ''')
        
        # Insert default domains if they don't exist
        default_domains = [
            ('haircut', 'Hair cutting and styling services'),
            ('massage', 'Relaxation and therapeutic massage'),
            ('counseling', 'Mental health and counseling services'),
            ('consultation', 'General consultation services')
        ]
        
        for domain_name, description in default_domains:
            cursor.execute('INSERT OR IGNORE INTO domains (name, description) VALUES (?, ?)', 
                         (domain_name, description))
        
        conn.commit()
        conn.close()
        logger.info("Domain database initialized successfully")
    except Exception as e:
        logger.error(f"Error initializing domain database: {str(e)}")

def get_domains():
    """Get all domains from database"""
    try:
        conn = sqlite3.connect('domainandslot.db')
        cursor = conn.cursor()
        cursor.execute('SELECT id, name, description FROM domains ORDER BY name')
        domains = cursor.fetchall()
        conn.close()
        return [{'id': d[0], 'name': d[1], 'description': d[2]} for d in domains]
    except Exception as e:
        logger.error(f"Error fetching domains: {str(e)}")
        return []

def get_timeslots(domain_id=None):
    """Get timeslots for a domain"""
    try:
        conn = sqlite3.connect('domainandslot.db')
        cursor = conn.cursor()
        if domain_id:
            cursor.execute('''
                SELECT t.id, t.start_time, t.end_time, t.is_active, d.name as domain_name
                FROM timeslots t
                JOIN domains d ON t.domain_id = d.id
                WHERE t.domain_id = ? AND t.is_active = 1
                ORDER BY t.start_time
            ''', (domain_id,))
        else:
            cursor.execute('''
                SELECT t.id, t.start_time, t.end_time, t.is_active, d.name as domain_name
                FROM timeslots t
                JOIN domains d ON t.domain_id = d.id
                WHERE t.is_active = 1
                ORDER BY d.name, t.start_time
            ''')
        timeslots = cursor.fetchall()
        conn.close()
        return [{'id': t[0], 'start_time': t[1], 'end_time': t[2], 'is_active': t[3], 'domain_name': t[4]} for t in timeslots]
    except Exception as e:
        logger.error(f"Error fetching timeslots: {str(e)}")
        return []

def add_domain(name, description):
    """Add a new domain"""
    try:
        conn = sqlite3.connect('domainandslot.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO domains (name, description) VALUES (?, ?)', (name, description))
        domain_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return domain_id
    except Exception as e:
        logger.error(f"Error adding domain: {str(e)}")
        return None

def add_timeslot(domain_id, start_time, end_time):
    """Add a new timeslot"""
    try:
        conn = sqlite3.connect('domainandslot.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO timeslots (domain_id, start_time, end_time) VALUES (?, ?, ?)', 
                      (domain_id, start_time, end_time))
        timeslot_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return timeslot_id
    except Exception as e:
        logger.error(f"Error adding timeslot: {str(e)}")
        return None

def delete_timeslot(timeslot_id):
    """Delete a timeslot"""
    try:
        conn = sqlite3.connect('domainandslot.db')
        cursor = conn.cursor()
        cursor.execute('UPDATE timeslots SET is_active = 0 WHERE id = ?', (timeslot_id,))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Error deleting timeslot: {str(e)}")
        return False

# Initialize domain database
init_domain_db()

# Store for current view
current_view_store = dcc.Store(id='current-view', data='chat')

# Enhanced external stylesheets
app = dash.Dash(__name__, external_stylesheets=[
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
    'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap'
], suppress_callback_exceptions=True)

# Clean professional layout with white design and fixed navigation
app.layout = html.Div([
    dcc.Store(id='session-data', data={
        'session_id': None, 
        'messages': [], 
        'model': 'llama-3.3-70b-versatile', 
        'is_stt': False,
        'trace_id': None
    }),
    current_view_store,
    
    # Fixed Professional Navigation Bar
    dbc.Navbar([
        dbc.Container([
            dbc.NavbarBrand([
                html.I(className="fas fa-robot me-2", style={'color': '#2563eb'}),
                "AI Appointment System"
            ], className="fw-bold", style={'fontSize': '24px', 'color': '#1f2937'}),
            
            dbc.Nav([
                dbc.NavItem(dbc.NavLink([
                    html.I(className="fas fa-comments me-2"),
                    "Chat Interface"
                ], href="#", id="nav-chat", className="nav-link-modern active")),
                dbc.NavItem(dbc.NavLink([
                    html.I(className="fas fa-chart-dashboard me-2"),
                    "Health Dashboard"
                ], href="#", id="nav-dashboard", className="nav-link-modern")),
                dbc.NavItem(dbc.NavLink([
                    html.I(className="fas fa-cogs me-2"),
                    "Domain Manager"
                ], href="#", id="nav-domains", className="nav-link-modern")),
            ], className="ms-auto"),
        ])
    ], color="white", dark=False, className="shadow-sm mb-0", style={'borderBottom': '2px solid #e5e7eb'}),
    
    # Main Content Area with forced white background
    html.Div(id='main-content', style={
        'minHeight': '100vh', 
        'backgroundColor': '#ffffff !important',
        'padding': '0'
    }),
    
    # Hidden elements for functionality
    html.Div(id='voice-output', style={'display': 'none'}),
    html.Div(id='voice-status', style={'display': 'none'}),
], style={'backgroundColor': '#ffffff'})

# Navigation callback
@app.callback(
    [Output('main-content', 'children'),
     Output('nav-chat', 'className'),
     Output('nav-dashboard', 'className'),
     Output('nav-domains', 'className'),
     Output('current-view', 'data')],
    [Input('nav-chat', 'n_clicks'),
     Input('nav-dashboard', 'n_clicks'),
     Input('nav-domains', 'n_clicks')],
    prevent_initial_call=False
)
def update_view(chat_clicks, dashboard_clicks, domains_clicks):
    ctx = callback_context
    
    if not ctx.triggered:
        return get_chat_interface(), "nav-link-modern active", "nav-link-modern", "nav-link-modern", 'chat'
    
    trigger = ctx.triggered[0]['prop_id'].split('.')[0]
    
    if trigger == 'nav-chat':
        return get_chat_interface(), "nav-link-modern active", "nav-link-modern", "nav-link-modern", 'chat'
    elif trigger == 'nav-dashboard':
        webbrowser.open('http://localhost:8000', new=2)
        return get_dashboard_redirect(), "nav-link-modern", "nav-link-modern active", "nav-link-modern", 'dashboard'
    elif trigger == 'nav-domains':
        return get_domains_interface(), "nav-link-modern", "nav-link-modern", "nav-link-modern active", 'domains'
    
    return get_chat_interface(), "nav-link-modern active", "nav-link-modern", "nav-link-modern", 'chat'

def get_chat_interface():
    """Return the clean white chat interface"""
    return html.Div([
        dbc.Container([
            dbc.Row([
                dbc.Col([
                    # Header Section with white background
                    html.Div([
                        html.Div([
                            html.H2([
                                html.I(className="fas fa-calendar-check me-3", style={'color': '#2563eb'}),
                                "AI Appointment Assistant"
                            ], className="text-center mb-1", 
                               style={'fontWeight': '700', 'color': '#1f2937', 'fontSize': '32px'}),
                            html.P("Book, check, or cancel appointments with natural language", 
                                  className="text-center mb-4", 
                                  style={'color': '#6b7280', 'fontSize': '18px'}),
                        ], className="text-center py-4", style={'backgroundColor': '#ffffff'})
                    ], style={'backgroundColor': '#ffffff'}),
                    
                    # Model and Session Info Cards
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardBody([
                                    html.H6([
                                        html.I(className="fas fa-brain me-2", style={'color': '#8b5cf6'}),
                                        "AI Model"
                                    ], className="card-title mb-3", style={'color': '#1f2937'}),
                                    dcc.Dropdown(
                                        id='model-selector',
                                        options=GROQ_MODELS,
                                        value='llama-3.3-70b-versatile',
                                        className="mb-0",
                                        style={'fontSize': '14px'}
                                    ),
                                ])
                            ], className="h-100 shadow-sm border-0", style={'backgroundColor': '#ffffff'})
                        ], md=6),
                        dbc.Col([
                            dbc.Card([
                                dbc.CardBody([
                                    html.H6([
                                        html.I(className="fas fa-info-circle me-2", style={'color': '#10b981'}),
                                        "Session Status"
                                    ], className="card-title mb-3", style={'color': '#1f2937'}),
                                    html.Div([
                                        dbc.Badge("Ready", color="success", className="me-2"),
                                        html.Small("New session", style={'color': '#6b7280'})
                                    ], id="session-info")
                                ])
                            ], className="h-100 shadow-sm border-0", style={'backgroundColor': '#ffffff'})
                        ], md=6),
                    ], className="mb-4"),
                    
                    # Chat Messages Area with white background
                    dbc.Card([
                        dbc.CardBody([
                            html.Div(id='chat-messages', 
                                   style={
                                       'height': '500px', 
                                       'overflowY': 'auto', 
                                       'padding': '20px',
                                       'backgroundColor': '#ffffff'
                                   })
                        ], className="p-0", style={'backgroundColor': '#ffffff'})
                    ], className="mb-4 shadow-sm border-0", 
                       style={'borderRadius': '12px', 'backgroundColor': '#ffffff'}),
                    
                    # Enhanced Input Area
                    dbc.Card([
                        dbc.CardBody([
                            dbc.InputGroup([
                                dbc.Input(
                                    id='user-input', 
                                    placeholder='Type your message (e.g., "Book a haircut on 04-08-2025 at 10:00 for John Doe")...',
                                    className="border-0",
                                    style={
                                        'borderRadius': '25px 0 0 25px',
                                        'fontSize': '16px',
                                        'padding': '12px 20px',
                                        'backgroundColor': '#f9fafb'
                                    }
                                ),
                                dbc.Button([
                                    html.I(id="voice-icon", className="fas fa-microphone me-2"), 
                                    html.Span("Voice", id="voice-text")
                                ], id='voice-button', color="light", outline=True, 
                                   className="px-4",
                                   style={
                                       'borderLeft': '1px solid #e5e7eb',
                                       'color': '#6b7280',
                                       'backgroundColor': '#f9fafb'
                                   }),
                                dbc.Button([
                                    html.I(className="fas fa-paper-plane me-2"), 
                                    "Send"
                                ], id='send-button', color="primary", 
                                   className="px-4",
                                   style={
                                       'borderRadius': '0 25px 25px 0',
                                       'backgroundColor': '#2563eb',
                                       'border': 'none'
                                   }),
                            ], className="shadow-sm"),
                        ], className="p-3", style={'backgroundColor': '#ffffff'})
                    ], className="shadow-sm border-0", 
                       style={'borderRadius': '12px', 'backgroundColor': '#ffffff'}),
                    
                    # Action Buttons
                    dbc.Row([
                        dbc.Col([
                            dbc.Button([
                                html.I(className="fas fa-plus me-2"), 
                                "New Chat"
                            ], id='new-chat-button', color="light", outline=True, 
                               className="w-100 py-2", 
                               style={'borderRadius': '8px', 'color': '#6b7280'}),
                        ], md=6),
                        dbc.Col([
                            dbc.Button([
                                html.I(className="fas fa-chart-line me-2"), 
                                "View Traces"
                            ], id='view-traces-button', color="info", outline=True, 
                               className="w-100 py-2",
                               style={'borderRadius': '8px'}),
                        ], md=6),
                    ], className="mt-4"),
                    
                ], lg=8, className="mx-auto")
            ])
        ], fluid=True, className="py-4", style={'backgroundColor': '#ffffff'})
    ], style={'backgroundColor': '#ffffff', 'minHeight': '100vh'})

def get_dashboard_redirect():
    """Return the dashboard redirect interface"""
    return html.Div([
        dbc.Container([
            dbc.Alert([
                html.H4([
                    html.I(className="fas fa-external-link-alt me-2"),
                    "Health Dashboard"
                ], className="alert-heading"),
                html.P("The Health Dashboard has opened in a new tab/window."),
                html.Hr(),
                dbc.Button("Open Dashboard Again", 
                          id="reopen-dashboard", 
                          color="primary",
                          href="http://localhost:8000",
                          target="_blank"),
            ], color="info", className="text-center")
        ], className="py-5")
    ], style={'backgroundColor': '#ffffff', 'minHeight': '100vh'})

def get_domains_interface():
    """Return the domain and timeslot management interface"""
    domains = get_domains()
    timeslots = get_timeslots()
    
    return html.Div([
        dbc.Container([
            # Header
            dbc.Row([
                dbc.Col([
                    html.H2([
                        html.I(className="fas fa-cogs me-3", style={'color': '#2563eb'}),
                        "Domain & Timeslot Manager"
                    ], style={'color': '#1f2937', 'fontWeight': '700'}),
                    html.P("Manage service domains and available time slots",
                          style={'color': '#6b7280'})
                ])
            ], className="mb-4"),
            
            # Domain Management Section
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader([
                            html.H5([
                                html.I(className="fas fa-tags me-2"),
                                "Service Domains"
                            ], className="mb-0")
                        ]),
                        dbc.CardBody([
                            # Add Domain Form
                            dbc.Row([
                                dbc.Col([
                                    dbc.Label("Domain Name"),
                                    dbc.Input(id="domain-name-input", placeholder="e.g., haircut")
                                ], md=4),
                                dbc.Col([
                                    dbc.Label("Description"),
                                    dbc.Input(id="domain-desc-input", placeholder="e.g., Hair cutting services")
                                ], md=6),
                                dbc.Col([
                                    dbc.Label("Action"),
                                    dbc.Button("Add Domain", id="add-domain-btn", color="success", className="w-100")
                                ], md=2),
                            ], className="mb-3"),
                            
                            # Existing Domains List
                            html.Div([
                                html.H6("Existing Domains:", className="mb-3"),
                                html.Div(id="domains-list", children=[
                                    dbc.Card([
                                        dbc.CardBody([
                                            html.Div([
                                                html.H6(domain['name'], className="mb-1"),
                                                html.P(domain['description'], className="text-muted mb-0", style={'fontSize': '14px'})
                                            ])
                                        ], className="py-2")
                                    ], className="mb-2 border-start border-primary border-4", style={'backgroundColor': '#ffffff'}) for domain in domains
                                ])
                            ])
                        ])
                    ], className="shadow-sm border-0", style={'backgroundColor': '#ffffff'})
                ], md=12),
            ], className="mb-4"),
            
            # Timeslot Management Section
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardHeader([
                            html.H5([
                                html.I(className="fas fa-clock me-2"),
                                "Time Slots Management"
                            ], className="mb-0")
                        ]),
                        dbc.CardBody([
                            # Add Timeslot Form
                            dbc.Row([
                                dbc.Col([
                                    dbc.Label("Select Domain"),
                                    dcc.Dropdown(
                                        id="timeslot-domain-select",
                                        options=[{'label': d['name'], 'value': d['id']} for d in domains],
                                        placeholder="Select a domain"
                                    )
                                ], md=3),
                                dbc.Col([
                                    dbc.Label("Start Time"),
                                    dbc.Input(id="timeslot-start-input", type="time", value="09:00")
                                ], md=3),
                                dbc.Col([
                                    dbc.Label("End Time"),
                                    dbc.Input(id="timeslot-end-input", type="time", value="10:00")
                                ], md=3),
                                dbc.Col([
                                    dbc.Label("Action"),
                                    dbc.Button("Add Timeslot", id="add-timeslot-btn", color="primary", className="w-100")
                                ], md=3),
                            ], className="mb-4"),
                            
                            # Existing Timeslots Table
                            html.Div([
                                html.H6("Current Time Slots:", className="mb-3"),
                                dbc.Table([
                                    html.Thead([
                                        html.Tr([
                                            html.Th("Domain"),
                                            html.Th("Start Time"),
                                            html.Th("End Time"),
                                            html.Th("Actions")
                                        ])
                                    ]),
                                    html.Tbody(id="timeslots-table-body", children=[
                                        html.Tr([
                                            html.Td(slot['domain_name']),
                                            html.Td(slot['start_time']),
                                            html.Td(slot['end_time']),
                                            html.Td([
                                                dbc.Button("Delete", 
                                                         id={'type': 'delete-timeslot', 'index': slot['id']},
                                                         color="danger", size="sm")
                                            ])
                                        ]) for slot in timeslots
                                    ])
                                ], striped=True, hover=True, style={'backgroundColor': '#ffffff'})
                            ])
                        ])
                    ], className="shadow-sm border-0", style={'backgroundColor': '#ffffff'})
                ], md=12),
            ])
        ], className="py-4")
    ], style={'backgroundColor': '#ffffff', 'minHeight': '100vh'})

# Domain management callbacks
@app.callback(
    [Output('domains-list', 'children'),
     Output('timeslot-domain-select', 'options'),
     Output('domain-name-input', 'value'),
     Output('domain-desc-input', 'value')],
    [Input('add-domain-btn', 'n_clicks')],
    [State('domain-name-input', 'value'),
     State('domain-desc-input', 'value')],
    prevent_initial_call=True
)
def manage_domains(n_clicks, domain_name, domain_desc):
    if n_clicks and domain_name and domain_desc:
        domain_id = add_domain(domain_name.strip(), domain_desc.strip())
        if domain_id:
            logger.info(f"Added domain: {domain_name}")
    
    # Refresh domains list
    domains = get_domains()
    
    domains_list = [
        dbc.Card([
            dbc.CardBody([
                html.Div([
                    html.H6(domain['name'], className="mb-1"),
                    html.P(domain['description'], className="text-muted mb-0", style={'fontSize': '14px'})
                ])
            ], className="py-2")
        ], className="mb-2 border-start border-primary border-4", 
           style={'backgroundColor': '#ffffff'}) for domain in domains
    ]
    
    domain_options = [{'label': d['name'], 'value': d['id']} for d in domains]
    
    return domains_list, domain_options, '', ''

@app.callback(
    [Output('timeslots-table-body', 'children'),
     Output('timeslot-start-input', 'value'),
     Output('timeslot-end-input', 'value')],
    [Input('add-timeslot-btn', 'n_clicks'),
     Input({'type': 'delete-timeslot', 'index': ALL}, 'n_clicks')],
    [State('timeslot-domain-select', 'value'),
     State('timeslot-start-input', 'value'),
     State('timeslot-end-input', 'value')],
    prevent_initial_call=True
)
def manage_timeslots(add_clicks, delete_clicks, domain_id, start_time, end_time):
    ctx = callback_context
    
    if ctx.triggered:
        trigger = ctx.triggered[0]['prop_id']
        
        if 'add-timeslot-btn' in trigger and add_clicks and domain_id and start_time and end_time:
            timeslot_id = add_timeslot(domain_id, start_time, end_time)
            if timeslot_id:
                logger.info(f"Added timeslot: {start_time}-{end_time} for domain {domain_id}")
        
        elif 'delete-timeslot' in trigger:
            # Extract timeslot ID from the trigger
            import json
            trigger_id = json.loads(trigger.split('.')[0])
            timeslot_id = trigger_id['index']
            if delete_timeslot(timeslot_id):
                logger.info(f"Deleted timeslot {timeslot_id}")
    
    # Refresh timeslots list
    timeslots = get_timeslots()
    
    timeslots_rows = [
        html.Tr([
            html.Td(slot['domain_name']),
            html.Td(slot['start_time']),
            html.Td(slot['end_time']),
            html.Td([
                dbc.Button("Delete", 
                         id={'type': 'delete-timeslot', 'index': slot['id']},
                         color="danger", size="sm")
            ])
        ]) for slot in timeslots
    ]
    
    return timeslots_rows, "09:00", "10:00"

# Helper function to create TTS button
def create_tts_button(text_content, button_id):
    """Create a TTS button with proper data attributes"""
    return html.Button(
        [html.I(className="fas fa-volume-up")], 
        id=button_id,
        className="tts-btn",
        style={
            'background': 'none',
            'border': 'none',
            'color': '#6b7280',
            'cursor': 'pointer',
            'padding': '4px 8px',
            'fontSize': '12px',
            'borderRadius': '4px'
        },
        **{'data-text': text_content}
    )

def format_response_text(text):
    """Format assistant response text for better readability"""
    # Add proper spacing and formatting
    formatted_text = text.replace("**", "")
    
    # Split into sentences and add proper spacing
    sentences = formatted_text.split('.')
    formatted_sentences = []
    
    for sentence in sentences:
        if sentence.strip():
            # Clean up the sentence
            clean_sentence = sentence.strip()
            if not clean_sentence.endswith('.') and clean_sentence:
                clean_sentence += '.'
            formatted_sentences.append(clean_sentence)
    
    # Join with proper spacing
    result = ' '.join(formatted_sentences)
    
    # Fix common formatting issues
    result = result.replace(' .', '.')
    result = result.replace('..', '.')
    result = result.replace('  ', ' ')
    
    return result.strip()

# Generate a session ID for tracking
import uuid
def generate_session_id():
    return str(uuid.uuid4())

# ✅ ENHANCED CHAT CALLBACK WITH PROPER MODEL TRACKING
@app.callback(
    [Output('chat-messages', 'children'),
     Output('user-input', 'value'),
     Output('session-data', 'data'),
     Output('voice-output', 'children', allow_duplicate=True),
     Output('voice-icon', 'className'),
     Output('voice-text', 'children'),
     Output('voice-button', 'color'),
     Output('session-info', 'children')],
    [Input('send-button', 'n_clicks'),
     Input('new-chat-button', 'n_clicks'),
     Input('voice-button', 'n_clicks'),
     Input('view-traces-button', 'n_clicks'),
     Input('model-selector', 'value'),  # ✅ Captures selected model
     Input('user-input', 'n_submit')],
    [State('user-input', 'value'),
     State('chat-messages', 'children'),
     State('session-data', 'data')],
    prevent_initial_call=True
)
def enhanced_chat_handler(send_clicks, new_chat_clicks, voice_clicks, trace_clicks, 
                         selected_model, enter_submit, user_input, messages, session_data):
    ctx = callback_context
    new_message = messages or []
    session_id = session_data.get('session_id')
    trace_id = session_data.get('trace_id')
    
    # ✅ Ensure selected_model is available throughout
    if not selected_model:
        selected_model = session_data.get('model', 'llama-3.3-70b-versatile')
    
    # Default session info with model information
    session_info = [
        dbc.Badge("Active", color="success", className="me-2"),
        html.Small(f"Session: {session_id[-8:] if session_id else 'None'} | Model: {selected_model.split('-')[0] if selected_model else 'None'}", 
                  style={'color': '#6b7280'})
    ]
    
    # Default voice button state
    voice_icon = "fas fa-microphone me-2"
    voice_text = "Voice"
    voice_color = "light"

    if not ctx.triggered:
        # Enhanced welcome message
        welcome_msg = html.Div([
            dbc.Card([
                dbc.CardBody([
                    html.Div([
                        html.H5([
                            html.I(className="fas fa-robot me-2", style={'color': '#2563eb'}),
                            "Welcome to AI Appointment Assistant!"
                        ], className="mb-3", style={'color': '#1f2937'}),
                        html.P("I can help you with:", className="mb-2", style={'color': '#374151'}),
                        html.Ul([
                            html.Li([
                                html.I(className="fas fa-calendar-check me-2", style={'color': '#10b981'}),
                                "Check availability: 'Show available slots on 04-08-2025'"
                            ], className="mb-2"),
                            html.Li([
                                html.I(className="fas fa-plus-circle me-2", style={'color': '#2563eb'}),
                                "Book appointments: 'Book a haircut on 04-08-2025 at 10:00 for John Doe'"
                            ], className="mb-2"),
                            html.Li([
                                html.I(className="fas fa-times-circle me-2", style={'color': '#ef4444'}),
                                "Cancel bookings: 'Cancel the appointment on 04-08-2025 at 10:00 for John Doe'"
                            ], className="mb-2"),
                            html.Li([
                                html.I(className="fas fa-sign-out-alt me-2", style={'color': '#f59e0b'}),
                                "End session: Type 'exit' when you're done"
                            ]),
                        ], className="ps-3", style={'listStyleType': 'none'}),
                        html.P([
                            html.Strong("Current Model: "),
                            html.Span(f"{selected_model}", style={'color': '#2563eb'})
                        ], className="mt-3 mb-0", style={'fontSize': '14px', 'color': '#6b7280'})
                    ])
                ])
            ], className="border-0 shadow-sm", 
               style={'backgroundColor': '#ffffff', 'borderLeft': '4px solid #2563eb'})
        ], className="mb-3")
        
        return [welcome_msg], '', session_data, '', voice_icon, voice_text, voice_color, session_info

    trigger = ctx.triggered[0]['prop_id']
    
    # Handle new chat
    if 'new-chat-button' in trigger:
        # UPDATED: Flush trace using SDK
        if session_id and trace_id:
            logger.info(f"Flushing trace {trace_id} for session {session_id}")
            flush_trace(trace_id, force=True)
        
        new_session_id = generate_session_id()
        session_data = {
            'session_id': new_session_id, 
            'messages': [], 
            'model': selected_model,  # ✅ Store selected model
            'is_stt': False,
            'trace_id': None
        }
        
        session_info = [
            dbc.Badge("New", color="success", className="me-2"),
            html.Small(f"Session: {new_session_id[-8:]} | Model: {selected_model.split('-')[0]}", 
                      style={'color': '#6b7280'})
        ]
        
        # Reset to welcome message with model info
        welcome_msg = html.Div([
            dbc.Card([
                dbc.CardBody([
                    html.H5([
                        html.I(className="fas fa-sparkles me-2", style={'color': '#f59e0b'}),
                        "Fresh Start!"
                    ], className="mb-2", style={'color': '#1f2937'}),
                    html.P(f"Ready to help with your appointment needs using {selected_model}!", 
                          className="mb-0", style={'color': '#374151'})
                ])
            ], className="border-0 shadow-sm", 
               style={'backgroundColor': '#ecfdf5', 'borderLeft': '4px solid #10b981'})
        ])
        
        return [welcome_msg], '', session_data, '', voice_icon, voice_text, voice_color, session_info
    
    # Handle model selector change
    if 'model-selector' in trigger and selected_model:
        # Update session data with new model
        session_data['model'] = selected_model
        logger.info(f"Model changed to: {selected_model} in session {session_id}")
        
        # Show model change confirmation
        model_change_msg = html.Div([
            dbc.Card([
                dbc.CardBody([
                    html.H6([
                        html.I(className="fas fa-brain me-2", style={'color': '#8b5cf6'}),
                        "Model Updated"
                    ], className="mb-2", style={'color': '#1f2937'}),
                    html.P(f"Now using: {selected_model}", className="mb-0", style={'color': '#374151'})
                ])
            ], className="border-0 shadow-sm", 
               style={'backgroundColor': '#faf5ff', 'borderLeft': '4px solid #8b5cf6'})
        ])
        
        new_message.append(model_change_msg)
        
        session_info = [
            dbc.Badge("Updated", color="info", className="me-2"),
            html.Small(f"Session: {session_id[-8:] if session_id else 'New'} | Model: {selected_model.split('-')[0]}", 
                      style={'color': '#6b7280'})
        ]
        
        return new_message, user_input or '', session_data, '', voice_icon, voice_text, voice_color, session_info
    
    # Handle send message (both button click and Enter key)
    if ('send-button' in trigger or 'user-input' in trigger) and user_input and user_input.strip():
        try:
            # Check if user wants to exit
            if user_input.lower().strip() in ['exit', 'quit', 'bye', 'goodbye']:
                # UPDATED: Flush trace using SDK
                if session_id and trace_id:
                    logger.info(f"User exit detected, flushing trace {trace_id}")
                    flush_trace(trace_id, force=True)
                    
                exit_msg = html.Div([
                    dbc.Card([
                        dbc.CardBody([
                            html.H5([
                                html.I(className="fas fa-hand-wave me-2", style={'color': '#f59e0b'}),
                                "Session Ended"
                            ], className="mb-2", style={'color': '#1f2937'}),
                            html.P("Thank you for using the appointment system! Your session has been saved and traces have been sent to server.", 
                                  className="mb-3", style={'color': '#374151'}),
                            dbc.Button("Start New Session", id="new-chat-trigger", color="primary", size="sm")
                        ])
                    ], className="border-0 shadow-sm", 
                       style={'backgroundColor': '#fef3c7', 'borderLeft': '4px solid #f59e0b'})
                ])
                
                new_message.append(exit_msg)
                session_data = {
                    'session_id': None, 
                    'messages': [], 
                    'model': selected_model,  # ✅ Preserve model selection
                    'is_stt': False,
                    'trace_id': None
                }
                
                return new_message, '', session_data, '', voice_icon, voice_text, voice_color, [
                    dbc.Badge("Ended", color="warning", className="me-2"),
                    html.Small(f"Session completed | Model: {selected_model.split('-')[0]}", 
                              style={'color': '#6b7280'})
                ]
            
            # Create user message bubble with model info
            user_bubble = html.Div([
                dbc.Card([
                    dbc.CardBody([
                        html.P(user_input, className="mb-2", style={'color': '#1f2937', 'margin': '0', 'fontWeight': '500'}),
                        html.Small(f"{datetime.now().strftime('%H:%M')} • {selected_model.split('-')[0]}", 
                                 style={'color': '#6b7280', 'fontSize': '11px'})
                    ], className="py-3 px-4")
                ], style={
                    'background': 'linear-gradient(135deg, #e0f2fe, #b3e5fc)',
                    'border': '1px solid #81d4fa',
                    'borderRadius': '18px 18px 4px 18px',
                    'maxWidth': '75%',
                    'marginLeft': 'auto'
                })
            ], className="d-flex justify-content-end mb-3")
            
            new_message.append(user_bubble)
            
            # Initialize session if needed
            if not session_id:
                session_id = generate_session_id()
                session_data['session_id'] = session_id
                session_data['model'] = selected_model  # ✅ Store model in session
                
            session_data['messages'].append(user_input)
            
            # ✅ ENHANCED STATE WITH PROPER MODEL TRACKING
            state = {
                "messages": [{"role": "user", "content": user_input}],
                "session_id": session_id,
                "pending_booking": {},
                "pending_cancellation": {},
                "trace_id": trace_id,
                "model": selected_model,  # ✅ Primary model field for tracing
                "user_selected_model": selected_model,  # ✅ Explicit model tracking
                "selected_model": selected_model,  # ✅ Additional field for clarity
                "ui_model": selected_model  # ✅ UI-specific model field
            }
            
            # ✅ ENHANCED CONFIG WITH MODEL INFORMATION
            config = {
                'configurable': {
                    'model': selected_model,  # ✅ Primary config model
                    'selected_model': selected_model,  # ✅ Backup model field
                    'ui_selected_model': selected_model  # ✅ UI model field
                },
                'model': selected_model,  # ✅ Top-level model field
                'runtime': {
                    'model': selected_model,  # ✅ Runtime model field
                    'user_model_selection': selected_model  # ✅ User selection tracking
                }
            }
            
            # Run the graph synchronously - tracing handled by SDK
            try:
                logger.info(f"🚀 Executing graph for session {session_id} with model {selected_model}")
                result = run_graph_sync(graph, state, config=config)
                logger.info(f"✅ Graph execution completed for session {session_id} using {selected_model}")
            except Exception as e:
                logger.error(f"❌ Error in graph execution for session {session_id}: {str(e)}")
                result = {
                    "messages": state["messages"] + [{"role": "assistant", "content": f"Sorry, I encountered an error: {str(e)}"}],
                    "session_id": session_id,
                    "trace_id": trace_id,
                    "model": selected_model  # ✅ Preserve model info in error case
                }
            
            # Extract and format response
            raw_response = result['messages'][-1]["content"] if result['messages'] else "No response generated."
            response_text = format_response_text(raw_response)
            
            # Update trace_id if new one was created
            if 'trace_id' in result and result['trace_id']:
                session_data['trace_id'] = result['trace_id']
            
            # Create assistant message bubble with model info
            tts_button_id = f"tts-{len(new_message)}"
            assistant_bubble = html.Div([
                dbc.Card([
                    dbc.CardBody([
                        html.Div([
                            html.P(response_text, className="mb-3", style={
                                'color': '#1f2937', 
                                'margin': '0',
                                'lineHeight': '1.6',
                                'fontSize': '15px'
                            }),
                            html.Div([
                                html.Small(f"{datetime.now().strftime('%H:%M')} • {selected_model.split('-')[0]}", 
                                          style={'color': '#6b7280', 'fontSize': '11px'}),
                                create_tts_button(response_text, tts_button_id)
                            ], className="d-flex align-items-center justify-content-between")
                        ])
                    ], className="py-3 px-4")
                ], style={
                    'backgroundColor': '#ffffff',
                    'border': '1px solid #e5e7eb',
                    'borderRadius': '18px 18px 18px 4px',
                    'maxWidth': '85%',
                    'boxShadow': '0 1px 3px rgba(0,0,0,0.1)'
                })
            ], className="mb-3", style={'textAlign': 'left'})
            
            new_message.append(assistant_bubble)
            
            logger.info(f"✅ Processed user request in session {session_id} using {selected_model}: {user_input[:50]}...")
            
            session_info = [
                dbc.Badge("Active", color="success", className="me-2"),
                html.Small(f"Session: {session_id[-8:]} | Model: {selected_model.split('-')[0]} | Trace: {session_data.get('trace_id', 'None')[-8:] if session_data.get('trace_id') else 'None'}", 
                          style={'color': '#6b7280'})
            ]
            
            return new_message, '', session_data, '', voice_icon, voice_text, voice_color, session_info
            
        except Exception as e:
            logger.error(f"❌ Error processing request in session {session_id}: {str(e)}")
            error_bubble = html.Div([
                dbc.Card([
                    dbc.CardBody([
                        html.H6([
                            html.I(className="fas fa-exclamation-triangle me-2", style={'color': '#ef4444'}),
                            "Error"
                        ], className="mb-2", style={'color': '#1f2937'}),
                        html.P(f"Sorry, I encountered an error: {str(e)}", className="mb-0", style={'color': '#374151'})
                    ])
                ], className="border-0 shadow-sm", 
                   style={'backgroundColor': '#fef2f2', 'borderLeft': '4px solid #ef4444'})
            ])
            new_message.append(error_bubble)
            
            return new_message, user_input or '', session_data, '', voice_icon, voice_text, voice_color, session_info
    
    return new_message, user_input or '', session_data, '', voice_icon, voice_text, voice_color, session_info

# Enhanced CSS styles
app.index_string = '''
<!DOCTYPE html>
<html>
<head>
    {%metas%}
    <title>🤖 AI Appointment System</title>
    {%favicon%}
    {%css%}
    <style>
        /* Force white background everywhere */
        html, body {
            font-family: 'Inter', sans-serif !important;
            background-color: #ffffff !important;
            color: #1f2937 !important;
            margin: 0 !important;
            padding: 0 !important;
        }
        
        body * {
            background-color: inherit;
        }
        
        .nav-link-modern {
            color: #6b7280 !important;
            font-weight: 500;
            padding: 12px 20px !important;
            border-radius: 8px;
            margin: 0 4px;
            transition: all 0.2s ease;
            text-decoration: none !important;
        }
        
        .nav-link-modern:hover {
            background-color: #f3f4f6 !important;
            color: #2563eb !important;
            transform: translateY(-1px);
        }
        
        .nav-link-modern.active {
            background-color: #2563eb !important;
            color: white !important;
        }
        
        .tts-btn {
            transition: all 0.2s ease;
            background: none !important;
            border: none !important;
            color: #6b7280 !important;
            cursor: pointer;
            padding: 4px 8px;
            font-size: 12px;
            border-radius: 4px;
        }
        
        .tts-btn:hover {
            color: #2563eb !important;
            background-color: #f3f4f6 !important;
        }
        
        .card {
            transition: all 0.2s ease;
            background-color: #ffffff !important;
        }
        
        .card:hover {
            transform: translateY(-1px);
        }
        
        .btn {
            font-weight: 500;
            border-radius: 8px;
            transition: all 0.2s ease;
        }
        
        .btn:hover {
            transform: translateY(-1px);
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 3px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
        
        /* Voice button animation */
        .recording {
            animation: pulse 1.5s infinite;
        }
        
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        
        /* Force white background on all major containers */
        ._dash-loading,
        ._dash-container,
        #react-entry-point,
        #_dash-app-content {
            background-color: #ffffff !important;
        }
        
        /* Ensure navbar stays white */
        .navbar {
            background-color: #ffffff !important;
        }
    </style>
</head>
<body>
    {%app_entry%}
    <footer>
        {%config%}
        {%scripts%}
        {%renderer%}
    </footer>
</body>
</html>
'''

# Client-side callbacks for speech recognition and TTS (unchanged)
app.clientside_callback(
    """
    function(voice_output, existing_input) {
        console.log('Voice callback triggered:', voice_output);
        
        if (voice_output === 'start_recognition') {
            console.log('Starting voice recognition...');
            
            if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
                alert('Speech recognition not supported in this browser. Please use Chrome, Edge, or Safari.');
                return existing_input || '';
            }
            
            const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
            recognition.lang = 'en-US';
            recognition.interimResults = false;
            recognition.continuous = false;
            recognition.maxAlternatives = 1;
            
            let finalTranscript = '';
            
            recognition.onstart = function() {
                console.log('Voice recognition started successfully');
                const voiceButton = document.getElementById('voice-button');
                if (voiceButton) {
                    voiceButton.classList.add('recording');
                }
            };
            
            recognition.onresult = function(event) {
                console.log('Recognition result received');
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    if (event.results[i].isFinal) {
                        finalTranscript += event.results[i][0].transcript;
                        console.log('Final transcript:', finalTranscript);
                    }
                }
            };
            
            recognition.onerror = function(event) {
                console.error('Speech recognition error:', event.error);
                const voiceButton = document.getElementById('voice-button');
                if (voiceButton) {
                    voiceButton.classList.remove('recording');
                }
                
                if (event.error === 'no-speech') {
                    alert('No speech detected. Please try again.');
                } else if (event.error === 'not-allowed') {
                    alert('Microphone access denied. Please allow microphone access and try again.');
                } else {
                    alert('Speech recognition error: ' + event.error);
                }
            };
            
            recognition.onend = function() {
                console.log('Voice recognition ended. Final transcript:', finalTranscript);
                const voiceButton = document.getElementById('voice-button');
                if (voiceButton) {
                    voiceButton.classList.remove('recording');
                }
                
                const inputElement = document.getElementById('user-input');
                if (inputElement) {
                    inputElement.value = finalTranscript;
                    
                    if (finalTranscript.trim()) {
                        setTimeout(() => {
                            const sendButton = document.getElementById('send-button');
                            if (sendButton) {
                                console.log('Auto-clicking send button');
                                sendButton.click();
                            }
                        }, 500);
                    }
                }
            };
            
            try {
                recognition.start();
            } catch (error) {
                console.error('Failed to start recognition:', error);
                alert('Failed to start voice recognition. Please try again.');
            }
            
            return existing_input || '';
        }
        
        return existing_input || '';
    }
    """,
    Output('user-input', 'value', allow_duplicate=True),
    [Input('voice-output', 'children')],
    [State('user-input', 'value')],
    prevent_initial_call='initial_duplicate'
)

# TTS callback
app.clientside_callback(
    """
    function(n_clicks) {
        document.addEventListener('click', function(e) {
            if (e.target.closest('.tts-btn')) {
                const button = e.target.closest('.tts-btn');
                const text = button.getAttribute('data-text') || '';
                
                if ('speechSynthesis' in window && text) {
                    window.speechSynthesis.cancel();
                    const utterance = new SpeechSynthesisUtterance(text);
                    utterance.lang = 'en-US';
                    utterance.rate = 0.9;
                    utterance.pitch = 1.0;
                    utterance.volume = 0.8;
                    window.speechSynthesis.speak(utterance);
                } else {
                    console.warn('Text-to-speech not supported or no text provided');
                }
            }
        });
        return '';
    }
    """,
    Output('voice-status', 'children'),
    [Input({'type': 'tts-btn', 'index': ALL}, 'n_clicks')],
    prevent_initial_call='initial_duplicate'
)

if __name__ == '__main__':
    logger.info("Starting Enhanced Appointment System on port 8051")
    print("🚀 Enhanced Appointment System Starting...")
    print("📱 Chat Interface: http://localhost:8051")
    print("📊 Health Dashboard: http://localhost:8000")
    print("🧠 Model Tracking: Enhanced with dynamic detection")
    app.run(debug=True, port=8051)