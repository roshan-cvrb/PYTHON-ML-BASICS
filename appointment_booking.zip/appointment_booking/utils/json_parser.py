import json
import re
import logging

logger = logging.getLogger(__name__)

def extract_json_from_response(response_content):
    if not response_content or not isinstance(response_content, str):
        raise ValueError("Invalid response content")
    
    cleaned_content = response_content.strip()
    
    try:
        return json.loads(cleaned_content)
    except json.JSONDecodeError:
        pass
    
    markdown_patterns = [
        r'```json\s*\n?(.*?)\n?```',
        r'```\s*\n?(.*?)\n?```',
        r'`([^`]+)`',
    ]
    
    for pattern in markdown_patterns:
        matches = re.findall(pattern, cleaned_content, re.DOTALL | re.IGNORECASE)
        for match in matches:
            try:
                cleaned_match = match.strip()
                if cleaned_match.startswith('{') and cleaned_match.endswith('}'):
                    return json.loads(cleaned_match)
            except json.JSONDecodeError:
                continue
    
    json_patterns = [
        r'\{[^{}]*"[^"]*"\s*:\s*"[^"]*"[^{}]*\}',
        r'\{[^{}]*"[^"]*"\s*:\s*[^,}]+[^{}]*\}',
        r'\{.*?\}',
    ]
    
    for pattern in json_patterns:
        matches = re.findall(pattern, cleaned_content, re.DOTALL)
        for match in matches:
            try:
                cleaned_match = match.strip()
                cleaned_match = re.sub(r',\s*}', '}', cleaned_match)
                cleaned_match = re.sub(r',\s*]', ']', cleaned_match)
                parsed = json.loads(cleaned_match)
                if isinstance(parsed, dict):
                    return parsed
            except json.JSONDecodeError:
                continue
    
    try:
        extracted_data = extract_key_value_pairs(cleaned_content)
        if extracted_data and isinstance(extracted_data, dict) and len(extracted_data) > 0:
            return extracted_data
    except Exception as e:
        logger.debug(f"Key-value extraction failed: {str(e)}")
    
    try:
        return fix_and_parse_json(cleaned_content)
    except Exception as e:
        logger.error(f"Failed to extract JSON from response: {str(e)}")
        raise ValueError("Could not parse LLM response as JSON")

def extract_key_value_pairs(text):
    result = {}
    patterns = {
        'date': [
            r'"?date"?\s*:\s*"?([^",\n\}]+)"?',
            r'\bdate[\s:=]+([^\s,\n\}]+)',
            r'date\s*(?:is|=|:)\s*([^\s,\n\}]+)',
        ],
        'time': [
            r'"?time"?\s*:\s*"?([^",\n\}]+)"?',
            r'\btime[\s:=]+([^\s,\n\}]+)',
            r'time\s*(?:is|=|:)\s*([^\s,\n\}]+)',
        ],
        'name': [
            r'"?name"?\s*:\s*"?([^",\n\}]+)"?',
            r'\bname[\s:=]+([^\s,\n\}]+(?:\s+[^\s,\n\}]+)*)',
            r'name\s*(?:is|=|:)\s*([^\s,\n\}]+(?:\s+[^\s,\n\}]+)*)',
        ],
        'domain': [
            r'"?domain"?\s*:\s*"?([^",\n\}]+)"?',
            r'\bdomain[\s:=]+([^\s,\n\}]+)',
            r'domain\s*(?:is|=|:)\s*([^\s,\n\}]+)',
            r'service[\s:=]+([^\s,\n\}]+)',
        ],
        'error': [
            r'"?error"?\s*:\s*"?([^",\n\}]+)"?',
            r'\berror[\s:=]+([^\n\}]+)',
        ]
    }
    
    for key, pattern_list in patterns.items():
        for pattern in pattern_list:
            match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
            if match:
                value = match.group(1).strip().strip('"\'').strip()
                if value and value.lower() not in ['null', 'none', '']:
                    result[key] = value
                    break
    
    for key, value in result.items():
        if isinstance(value, str):
            cleaned_value = re.sub(r'^["\'\s]+|["\'\s]+$', '', value)
            cleaned_value = re.sub(r'\s+', ' ', cleaned_value).strip()
            if cleaned_value:
                result[key] = cleaned_value
    
    return result if result else {}

def fix_and_parse_json(text):
    json_start = text.find('{')
    json_end = text.rfind('}')
    
    if json_start != -1 and json_end != -1 and json_end > json_start:
        json_text = text[json_start:json_end + 1]
        fixes = [
            (r',\s*}', '}'),
            (r',\s*]', ']'),
            (r'(\w+)\s*:', r'"\1":'),
            (r"'([^']*)'", r'"\1"'),
            (r',\s*,', ','),
        ]
        
        for pattern, replacement in fixes:
            json_text = re.sub(pattern, replacement, json_text)
        
        try:
            return json.loads(json_text)
        except json.JSONDecodeError:
            pass
    
    raise ValueError("Could not fix and parse JSON")

def safe_json_loads(content, fallback_dict=None):
    if fallback_dict is None:
        fallback_dict = {"error": "Invalid JSON response"}
    
    if not content or not isinstance(content, str):
        logger.warning("Empty or invalid content provided to safe_json_loads")
        return fallback_dict
    
    try:
        result = extract_json_from_response(content)
        if isinstance(result, dict):
            if result and any(key for key in result.keys() if key != "error"):
                return result
            else:
                logger.warning("Parsed JSON but contains no meaningful data")
                return fallback_dict
        else:
            logger.warning(f"Parsed result is not a dictionary: {type(result)}")
            return fallback_dict
    except Exception as e:
        logger.error(f"JSON parsing error: {str(e)}")
        logger.debug(f"Failed content: {content[:200]}...")
        return fallback_dict

def validate_extracted_data(data, required_keys=None):
    if not isinstance(data, dict):
        return {"error": "Data is not a dictionary"}
    
    if "error" in data:
        return data
    
    if required_keys:
        missing_keys = [key for key in required_keys if not data.get(key)]
        if missing_keys:
            return {"error": f"Missing required fields: {', '.join(missing_keys)}"}
    
    cleaned_data = {}
    for key, value in data.items():
        if isinstance(value, str):
            cleaned_value = value.strip().strip('"\'')
            if cleaned_value:
                cleaned_data[key] = cleaned_value
        else:
            cleaned_data[key] = value
    
    return cleaned_data

def extract_booking_data(response):
    data = safe_json_loads(response)
    return validate_extracted_data(data, required_keys=['date', 'time', 'name'])

def extract_availability_data(response):
    data = safe_json_loads(response)
    return validate_extracted_data(data, required_keys=['date'])

def extract_cancellation_data(response):
    data = safe_json_loads(response)
    return validate_extracted_data(data, required_keys=['date', 'time', 'name'])