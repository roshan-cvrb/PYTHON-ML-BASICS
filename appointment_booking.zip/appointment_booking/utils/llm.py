# utils/llm.py
from langchain_groq import ChatGroq
import os
from dotenv import load_dotenv
import logging

# Load environment variables from .env file
load_dotenv()

logger = logging.getLogger(__name__)

def get_llm(model_name="llama-3.3-70b-versatile"):
    """
    Get LLM instance with proper configuration for tracing
    """
    try:
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            raise ValueError("GROQ_API_KEY not found in environment variables")
        
        llm = ChatGroq(
            groq_api_key=api_key,
            model_name=model_name,
            temperature=0.1,  # Low temperature for consistent responses
            max_tokens=1000,  # Reasonable limit
            timeout=30,  # 30 second timeout
        )
        
        logger.info(f"LLM instance created with model: {model_name}")
        return llm
        
    except Exception as e:
        logger.error(f"Error creating LLM instance: {str(e)}")
        raise