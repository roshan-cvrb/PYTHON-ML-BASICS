import sqlite3
import os
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/database.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Database file
DB_FILE = "data/appointments.db"

def init_db():
    """Initialize the SQLite database and create the appointments table if it doesn't exist."""
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            name TEXT NOT NULL,
            domain TEXT NOT NULL DEFAULT 'haircut',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    # Verify table creation
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='appointments';")
    if not cursor.fetchone():
        logger.error("Failed to create appointments table")
    else:
        logger.info("Appointments table verified")
    conn.close()

def load_appointments(date=None, domain='haircut'):
    """
    Load appointments for a specific date and domain.
    If date is None, return all appointments.
    Returns a dictionary {date: [{time, name, id}, ...]} for compatibility with existing code.
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    if date:
        cursor.execute("SELECT id, date, time, name FROM appointments WHERE date = ? AND domain = ?", (date, domain))
    else:
        cursor.execute("SELECT id, date, time, name FROM appointments WHERE domain = ?", (domain,))
    rows = cursor.fetchall()
    conn.close()

    appointments = {}
    for row in rows:
        appointment_id, date, time, name = row
        if date not in appointments:
            appointments[date] = []
        appointments[date].append({"id": appointment_id, "time": time, "name": name})
    logger.info(f"Loaded appointments for date {date}, domain {domain}: {appointments}")
    return appointments

def save_appointment(date, time, name, domain='haircut'):
    """Save a new appointment and return its ID."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO appointments (date, time, name, domain) VALUES (?, ?, ?, ?)",
            (date, time, name, domain)
        )
        conn.commit()
        appointment_id = cursor.lastrowid
        logger.info(f"Saved appointment: {date} {time} for {name}, domain {domain}, ID {appointment_id}")
        # Verify insertion
        cursor.execute("SELECT id FROM appointments WHERE date = ? AND time = ? AND name = ? AND domain = ?", (date, time, name, domain))
        if cursor.fetchone():
            logger.info(f"Verified appointment ID {appointment_id} in database")
        else:
            logger.error(f"Failed to verify appointment ID {appointment_id} in database")
    except sqlite3.Error as e:
        logger.error(f"Database error while saving appointment: {str(e)}")
        conn.rollback()
        raise
    finally:
        conn.close()
    return appointment_id

def delete_appointment(date, time, name, domain='haircut'):
    """Delete an appointment and return True if successful, False if not found."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "DELETE FROM appointments WHERE date = ? AND time = ? AND LOWER(name) = LOWER(?) AND domain = ?",
            (date, time, name, domain)
        )
        conn.commit()
        affected_rows = cursor.rowcount
        if affected_rows > 0:
            logger.info(f"Deleted appointment: {date} {time} for {name}, domain {domain}")
            reset_id_sequence()
            return True
        logger.info(f"No appointment found to delete: {date} {time} for {name}, domain {domain}")
        return False
    except sqlite3.Error as e:
        logger.error(f"Database error while deleting appointment: {str(e)}")
        conn.rollback()
        return False
    finally:
        conn.close()

def reset_id_sequence():
    """Reset the AUTOINCREMENT sequence for the appointments table."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT MAX(id) FROM appointments")
        max_id = cursor.fetchone()[0]
        if max_id is None:
            max_id = 0
        cursor.execute("DELETE FROM sqlite_sequence WHERE name='appointments'")
        cursor.execute("INSERT INTO sqlite_sequence (name, seq) VALUES ('appointments', ?)", (max_id,))
        conn.commit()
        logger.info(f"Reset ID sequence to {max_id}")
    except sqlite3.Error as e:
        logger.error(f"Error resetting ID sequence: {str(e)}")
        conn.rollback()
    finally:
        conn.close()

def get_all_appointments():
    """Retrieve all appointments for the admin dashboard."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id, date, time, name, domain, created_at FROM appointments")
        rows = cursor.fetchall()
        logger.info(f"Retrieved {len(rows)} appointments from database")
    except sqlite3.Error as e:
        logger.error(f"Error retrieving appointments: {str(e)}")
        rows = []
    finally:
        conn.close()
    return [
        {
            "id": row[0],
            "date": row[1],
            "time": row[2],
            "name": row[3],
            "domain": row[4],
            "created_at": row[5]
        }
        for row in rows
    ]

# Initialize the database on module import
init_db()