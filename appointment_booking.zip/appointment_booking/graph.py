# graph.py
from langgraph.graph import StateGraph, END
from typing import TypedDict, List, Dict
from agents.supervisor_agent import supervisor_agent
from agents.availability_agent import availability_agent
from agents.confirmation_agent import confirmation_agent
from agents.cancellation_agent import cancellation_agent
from tracing.trace_collector import set_active_trace_id, get_active_trace_id  # UPDATED IMPORT
import uuid
import asyncio

class AgentState(TypedDict):
    messages: List[Dict]
    next_agent: str
    pending_booking: Dict
    pending_cancellation: Dict
    session_id: str
    trace_id: str

def create_graph():
    """Create and return the compiled graph"""
    workflow = StateGraph(AgentState)
    
    # Define nodes - agents will handle their own tracing
    workflow.add_node("supervisor", supervisor_agent)
    workflow.add_node("availability", availability_agent)
    workflow.add_node("confirmation", confirmation_agent)
    workflow.add_node("cancellation", cancellation_agent)
    
    # Define routing function that handles missing next_agent
    def route_next_agent(state):
        next_agent = state.get("next_agent", "end")
        # Ensure it's a valid route
        valid_routes = ["availability", "confirmation", "cancellation", "end"]
        if next_agent not in valid_routes:
            return "end"
        return next_agent
    
    # Define edges from supervisor
    workflow.add_conditional_edges(
        "supervisor",
        route_next_agent,
        {
            "availability": "availability",
            "confirmation": "confirmation",
            "cancellation": "cancellation",
            "end": END
        }
    )
    
    # All agents go to END after processing
    workflow.add_edge("availability", END)
    workflow.add_edge("confirmation", END)
    workflow.add_edge("cancellation", END)
    
    # Set entry point
    workflow.set_entry_point("supervisor")
    
    return workflow.compile()

async def run_graph_async(graph, state, config=None):
    """Async wrapper to run the graph"""
    try:
        # Ensure trace context is set
        trace_id = state.get('trace_id') or f"trace_{uuid.uuid4()}"
        state['trace_id'] = trace_id
        set_active_trace_id(trace_id)
        
        # Ensure all required keys exist
        if 'next_agent' not in state:
            state['next_agent'] = 'supervisor'
        if 'pending_booking' not in state:
            state['pending_booking'] = {}
        if 'pending_cancellation' not in state:
            state['pending_cancellation'] = {}
        
        # Run the graph
        result = await graph.ainvoke(state, config=config or {})
        return result
    except Exception as e:
        print(f"Error in graph execution: {str(e)}")
        # Return safe default state
        return {
            "messages": state.get("messages", []) + [
                {"role": "assistant", "content": f"I encountered an error: {str(e)}. Please try again."}
            ],
            "next_agent": "end",
            "session_id": state.get("session_id"),
            "trace_id": state.get("trace_id"),
            "pending_booking": {},
            "pending_cancellation": {}
        }

def run_graph_sync(graph, state, config=None):
    """Synchronous wrapper to run the graph"""
    try:
        # Ensure all required keys exist
        if 'next_agent' not in state:
            state['next_agent'] = 'supervisor'
        if 'pending_booking' not in state:
            state['pending_booking'] = {}
        if 'pending_cancellation' not in state:
            state['pending_cancellation'] = {}
        
        # Create new event loop if none exists
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If loop is running, use thread executor
                import concurrent.futures
                import threading
                
                def run_in_thread():
                    new_loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(new_loop)
                    try:
                        return new_loop.run_until_complete(run_graph_async(graph, state, config))
                    finally:
                        new_loop.close()
                
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(run_in_thread)
                    return future.result()
            else:
                return loop.run_until_complete(run_graph_async(graph, state, config))
        except RuntimeError:
            # No event loop in current thread
            return asyncio.run(run_graph_async(graph, state, config))
            
    except Exception as e:
        print(f"Error in synchronous graph execution: {str(e)}")
        # Return a safe default response structure
        return {
            "messages": state.get("messages", []) + [
                {"role": "assistant", "content": f"I encountered an error: {str(e)}. Please try again."}
            ],
            "next_agent": "end",
            "session_id": state.get("session_id"),
            "trace_id": state.get("trace_id"),
            "pending_booking": {},
            "pending_cancellation": {}
        }