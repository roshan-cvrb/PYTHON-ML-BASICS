# agents/cancellation_agent.py - Updated with Standard Logging (No Session Tracker)
from langchain_core.messages import AIMessage
from utils.llm import get_llm
from utils.database import load_appointments, delete_appointment, get_all_appointments
from utils.json_parser import safe_json_loads
# REMOVED: session_tracker import
# UPDATED: Import SDK functions
from tracing.decorators import trace_agent, trace_llm_call
from tracing.trace_collector import configure_tracing_server, check_tracing_server
from datetime import datetime
import json
from typing import Dict
import re
import logging
import os

# Setup consistent logging like dashapp.py
logger = logging.getLogger(__name__)

# CONFIGURE SDK FOR THIS AGENT
TRACING_SERVER_URL = os.getenv("TRACING_SERVER_URL", "http://localhost:8000")

# Initialize SDK (only configure once per agent)
try:
    configure_tracing_server(TRACING_SERVER_URL)
    if not check_tracing_server():
        logger.warning("⚠️ Tracing server not available for cancellation agent")
    else:
        logger.info("✅ Cancellation agent connected to tracing server")
except Exception as e:
    logger.warning(f"Could not initialize tracing SDK for cancellation agent: {str(e)}")

@trace_agent("cancellation", "booking_management_agent", framework="langgraph")
async def cancellation_agent(state: Dict) -> Dict:
    session_id = state.get("session_id", "unknown")
    messages = state["messages"]
    
    # ✅ GET DYNAMIC MODEL FROM STATE
    selected_model = state.get("model") or state.get("user_selected_model") or state.get("selected_model", "llama-3.3-70b-versatile")
    
    user_input = next((msg["content"] for msg in reversed(messages) if msg["role"] == "user"), None)
    
    if not user_input:
        logger.info(f"No user input provided for cancellation in session {session_id}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": "No user input found. Please provide a cancellation request, e.g., 'Cancel the appointment on 04-08-2025 at 10:00 for John Doe'."}],
            "next_agent": "end",
            "pending_cancellation": {}
        }

    logger.info(f"Processing cancellation request in session {session_id} with model {selected_model}: {user_input}")
    
    # Preprocess input to normalize common variations
    processed_input = preprocess_cancellation_input(user_input)
    
    @trace_llm_call("cancellation_details_extraction", framework="langgraph")
    async def extract_cancellation_details(prompt: str, model: str):
        llm = get_llm(model)
        return await llm.ainvoke(prompt)

    # Use LLM to extract cancellation details with stricter JSON format
    prompt = f"""
    CRITICAL: Respond with ONLY a valid JSON object. No explanations, no markdown, no additional text.

    Extract cancellation details from this request.
    Respond with ONLY this JSON format: {{"date": "DD-MM-YYYY", "time": "HH:MM", "name": "Full Name", "domain": "service_type"}}

    Requirements:
    - Date: DD-MM-YYYY format (e.g., 04-08-2025)
    - Time: HH:MM format (e.g., 10:00, 22:00)  
    - Name: Full name, remove possessive forms (e.g., "John Doe's" → "John Doe")
    - Domain: Must be 'haircut', 'massage', or 'counselling'. Try to infer from context or default to 'haircut'
    
    If missing required fields (date, time, or name), respond with:
    {{"error": "Missing required cancellation details"}}
    
    User input: {processed_input}

    Respond with ONLY the JSON object:
    """

    logger.info(f"Sending request to LLM for cancellation details extraction in session {session_id} using model {selected_model}")
    
    try:
        # ✅ USE DYNAMIC MODEL FROM STATE
        response = await extract_cancellation_details(prompt, selected_model)
        logger.info(f"LLM response in session {session_id}: {response.content}")
        
        # Use robust JSON parsing
        data = safe_json_loads(response.content, {"error": "Could not parse cancellation details"})
        
        if "error" in data:
            logger.info(f"Invalid cancellation details in session {session_id}: {data['error']}")
            return {
                **state,
                "messages": messages + [{"role": "assistant", "content": f"❌ {data['error']}\n\n💡 *Please provide: date, time, and your name*\n*Example: 'Cancel appointment on 04-08-2025 at 10:00 for John Doe'*"}],
                "next_agent": "end",
                "pending_cancellation": {}
            }
        else:
            date_str = data.get("date", "")
            time_str = data.get("time", "")
            name = data.get("name", "").strip().rstrip("'s")
            domain = data.get("domain", "haircut")
            
    except Exception as e:
        logger.error(f"Error in LLM request for session {session_id}: {str(e)}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": f"❌ Error processing request: {str(e)}"}],
            "next_agent": "end",
            "pending_cancellation": {}
        }

    logger.info(f"Extracted details in session {session_id} using model {selected_model} - Date: {date_str}, Time: {time_str}, Name: {name}, Domain: {domain}")

    # Validate extracted details
    validation_result = validate_cancellation_details(date_str, time_str, name, domain)
    if not validation_result["valid"]:
        logger.info(f"Validation failed in session {session_id}: {validation_result['error']}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": f"❌ {validation_result['error']}"}],
            "next_agent": "end",
            "pending_cancellation": {}
        }

    # Search for the appointment to cancel
    try:
        appointment_found = find_appointment_to_cancel(date_str, time_str, name, domain)
        
        if not appointment_found:
            # Try to find appointment across all domains
            alternative_appointment = find_appointment_across_domains(date_str, time_str, name)
            
            if alternative_appointment:
                logger.info(f"Found appointment in different domain in session {session_id}: {alternative_appointment}")
                domain = alternative_appointment['domain']
                appointment_found = alternative_appointment
            else:
                logger.info(f"No appointment found for {name} on {date_str} at {time_str} in session {session_id}")
                
                # Provide helpful suggestions
                suggestions = get_cancellation_suggestions(name, date_str, time_str)
                response_text = f"❌ **Appointment Not Found**\n\n"
                response_text += f"No {domain} appointment found for **{name}** on {date_str} at {time_str}.\n\n"
                
                if suggestions:
                    response_text += "**Did you mean one of these?**\n" + suggestions + "\n\n"
                
                response_text += "💡 *Please check the date, time, and name, or contact support for assistance.*"
                
                return {
                    **state,
                    "messages": messages + [{"role": "assistant", "content": response_text}],
                    "next_agent": "end",
                    "pending_cancellation": {}
                }

        # Proceed with cancellation
        logger.info(f"Canceling booking for {name} on {date_str} at {time_str}, domain {domain} in session {session_id}")
        
        success = delete_appointment(date_str, time_str, name, domain)
        
        if success:
            response_text = f"✅ **Cancellation Successful**\n\n"
            response_text += f"📅 **Date:** {format_date_display(date_str)}\n"
            response_text += f"🕐 **Time:** {time_str}\n"
            response_text += f"👤 **Name:** {name}\n"
            response_text += f"🏷️ **Service:** {domain.title()}\n\n"
            response_text += f"🎉 *Your appointment has been successfully canceled!*\n"
            response_text += f"💡 *You can book a new appointment anytime.*"
            
            logger.info(f"Successfully canceled booking for {name} on {date_str} at {time_str}, domain {domain} in session {session_id}")
            return {
                **state,
                "messages": messages + [{"role": "assistant", "content": response_text}],
                "next_agent": "end",
                "pending_cancellation": {}
            }
            
        else:
            response_text = f"❌ **Cancellation Failed**\n\n"
            response_text += f"Could not cancel the appointment for **{name}** on {date_str} at {time_str} ({domain}).\n\n"
            response_text += f"💡 *Please try again or contact support for assistance.*"
            
            logger.error(f"Failed to cancel booking for {name} on {date_str} at {time_str}, domain {domain} in session {session_id}")
            return {
                **state,
                "messages": messages + [{"role": "assistant", "content": response_text}],
                "next_agent": "end",
                "pending_cancellation": {}
            }

    except Exception as e:
        logger.error(f"Error during cancellation process in session {session_id}: {str(e)}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": f"❌ Error during cancellation process: {str(e)}"}],
            "next_agent": "end",
            "pending_cancellation": {}
        }

# Helper functions (keeping all existing ones with removed log_action calls)
def preprocess_cancellation_input(user_input: str) -> str:
    """Preprocess user input to normalize common variations"""
    user_input = user_input.lower().strip()
    
    # Normalize common phrases
    user_input = re.sub(r'\s*at\s+', ' ', user_input)
    user_input = re.sub(r'\bcancel\s+(the\s+)?', 'cancel ', user_input)
    user_input = re.sub(r'\bremove\s+(my\s+)?', 'cancel ', user_input)
    user_input = re.sub(r'\bdelete\s+(my\s+)?', 'cancel ', user_input)
    
    # Normalize time formats
    user_input = re.sub(r'(\b)(\d{1,2}):(\d{2})(\b)', r'\1\2:\3\4', user_input)
    user_input = re.sub(r'(\b)(\d{1,2})(am|pm)(\b)', 
                        lambda m: f"{m.group(1)}{convert_12_to_24_hour(m.group(2), m.group(3))}{m.group(4)}", 
                        user_input, flags=re.IGNORECASE)
    
    # Normalize date formats
    user_input = re.sub(r'(\b)(\d{1,2})[/-](\d{1,2})[/-](\d{4})(\b)', r'\1\2-\3-\4\5', user_input)
    user_input = re.sub(r'(\b)(\d{1,2})[/-](\d{1,2})[/-](\d{2})(\b)', r'\1\2-\3-20\4\5', user_input)
    
    # Pad single digits with zeros
    user_input = re.sub(r'(\b)(\d)-(\d{1,2})-(\d{4})(\b)', r'\g<1>0\2-\3-\4\5', user_input)
    user_input = re.sub(r'(\b)(\d{1,2})-(\d)-(\d{4})(\b)', r'\g<1>\2-0\3-\4\5', user_input)
    user_input = re.sub(r'(\b)(\d)-(\d)-(\d{4})(\b)', r'\g<1>0\2-0\3-\4\5', user_input)
    
    logger.debug(f"Preprocessed cancellation input: {user_input}")
    return user_input

def convert_12_to_24_hour(hour_str: str, period: str) -> str:
    """Convert 12-hour format to 24-hour format"""
    hour = int(hour_str)
    if period.lower() == 'pm' and hour != 12:
        hour += 12
    elif period.lower() == 'am' and hour == 12:
        hour = 0
    return f"{hour:02d}:00"

def validate_cancellation_details(date_str: str, time_str: str, name: str, domain: str) -> dict:
    """Validate all cancellation details"""
    
    # Validate date format and value
    try:
        if not date_str:
            return {"valid": False, "error": "Date is required. Please provide a date in DD-MM-YYYY format."}
        datetime.strptime(date_str, "%d-%m-%Y")
    except ValueError:
        return {"valid": False, "error": f"Invalid date format: '{date_str}'. Please use DD-MM-YYYY format (e.g., 04-08-2025)."}
    
    # Validate time format
    try:
        if not time_str:
            return {"valid": False, "error": "Time is required. Please provide a time in HH:MM format."}
        datetime.strptime(time_str, "%H:%M")
    except ValueError:
        return {"valid": False, "error": f"Invalid time format: '{time_str}'. Please use HH:MM format (e.g., 10:00, 14:30)."}
    
    # Validate name
    if not name or len(name.strip()) < 2:
        return {"valid": False, "error": f"Valid name is required. Please provide your full name (e.g., 'John Doe')."}
    
    # Validate domain
    valid_domains = ['haircut', 'massage', 'counselling']
    if domain not in valid_domains:
        logger.warning(f"Unknown domain '{domain}', defaulting to 'haircut'")
        domain = 'haircut'
    
    return {"valid": True, "error": None}

def find_appointment_to_cancel(date_str: str, time_str: str, name: str, domain: str) -> dict:
    """Find the specific appointment to cancel"""
    try:
        appointments = load_appointments(date=date_str, domain=domain)
        booked_slots = appointments.get(date_str, [])
        
        # Look for exact match
        for booking in booked_slots:
            if (booking["time"] == time_str and 
                booking["name"].lower().strip() == name.lower().strip()):
                return {
                    "id": booking.get("id"),
                    "date": date_str,
                    "time": time_str,
                    "name": booking["name"],
                    "domain": domain
                }
        return None
        
    except Exception as e:
        logger.error(f"Error finding appointment: {str(e)}")
        return None

def find_appointment_across_domains(date_str: str, time_str: str, name: str) -> dict:
    """Search for appointment across all service domains"""
    domains = ['haircut', 'massage', 'counselling']
    
    for domain in domains:
        try:
            appointments = load_appointments(date=date_str, domain=domain)
            booked_slots = appointments.get(date_str, [])
            
            for booking in booked_slots:
                if (booking["time"] == time_str and 
                    booking["name"].lower().strip() == name.lower().strip()):
                    return {
                        "id": booking.get("id"),
                        "date": date_str,
                        "time": time_str,
                        "name": booking["name"],
                        "domain": domain
                    }
        except Exception as e:
            logger.error(f"Error searching domain {domain}: {str(e)}")
            continue
    
    return None

def get_cancellation_suggestions(name: str, date_str: str, time_str: str) -> str:
    """Get suggestions for similar appointments that might be what the user meant"""
    suggestions = []
    
    try:
        # Get all appointments for the name
        all_appointments = get_all_appointments()
        user_appointments = [apt for apt in all_appointments 
                           if apt["name"].lower().strip() == name.lower().strip()]
        
        if user_appointments:
            suggestions.append("**Your existing appointments:**")
            for apt in user_appointments[:3]:  # Show max 3
                formatted_date = format_date_display(apt["date"])
                suggestions.append(f"• {formatted_date} at {apt['time']} - {apt['domain'].title()}")
        
        # Check for appointments on the same date with different times
        date_appointments = [apt for apt in all_appointments if apt["date"] == date_str]
        if date_appointments:
            suggestions.append(f"\n**Other appointments on {format_date_display(date_str)}:**")
            for apt in date_appointments[:3]:
                suggestions.append(f"• {apt['time']} - {apt['name']} ({apt['domain'].title()})")
    
    except Exception as e:
        logger.error(f"Error generating suggestions: {str(e)}")
        return ""
    
    return "\n".join(suggestions) if suggestions else ""

def format_date_display(date_str: str) -> str:
    """Format date string for better display"""
    try:
        parsed_date = datetime.strptime(date_str, "%d-%m-%Y")
        return parsed_date.strftime("%A, %B %d, %Y")
    except:
        return date_str