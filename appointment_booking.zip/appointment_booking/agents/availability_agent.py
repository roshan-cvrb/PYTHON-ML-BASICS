# agents/availability_agent.py - Updated with Standard Logging (No Session Tracker)
from langchain_core.messages import AIMessage
from utils.llm import get_llm
from utils.database import load_appointments
from utils.json_parser import safe_json_loads
# REMOVED: session_tracker import
# UPDATED: Import SDK functions
from tracing.decorators import trace_agent, trace_llm_call
from tracing.trace_collector import configure_tracing_server, check_tracing_server
from datetime import datetime, timedelta
import json
from typing import Dict
import re
import logging
import os

# Setup consistent logging like dashapp.py
logger = logging.getLogger(__name__)

# CONFIGURE SDK FOR THIS AGENT
TRACING_SERVER_URL = os.getenv("TRACING_SERVER_URL", "http://localhost:8000")

# Initialize SDK (only configure once per agent)
try:
    configure_tracing_server(TRACING_SERVER_URL)
    if not check_tracing_server():
        logger.warning("⚠️ Tracing server not available for availability agent")
    else:
        logger.info("✅ Availability agent connected to tracing server")
except Exception as e:
    logger.warning(f"Could not initialize tracing SDK for availability agent: {str(e)}")

@trace_agent("availability", "scheduling_agent", framework="langgraph")
async def availability_agent(state: Dict) -> Dict:
    session_id = state.get("session_id", "unknown")
    messages = state["messages"]
    
    # ✅ GET DYNAMIC MODEL FROM STATE
    selected_model = state.get("model") or state.get("user_selected_model") or state.get("selected_model", "llama-3.3-70b-versatile")
    
    user_input = next((msg["content"] for msg in reversed(messages) if msg["role"] == "user"), None)
    
    if not user_input:
        logger.info(f"No user input found in session {session_id}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": "No user input found. Please specify a date to check availability, e.g., 'Show available slots on 04-08-2025'."}],
            "next_agent": "end"
        }
    
    logger.info(f"Processing availability request in session {session_id} with model {selected_model}: {user_input}")
    
    # Preprocess input to normalize date formats
    processed_input = preprocess_availability_input(user_input)
    
    @trace_llm_call("date_domain_extraction", framework="langgraph")
    async def extract_date_and_domain(prompt: str, model: str):
        llm = get_llm(model)
        return await llm.ainvoke(prompt)
    
    # Extract date and domain from user input with stricter JSON format
    prompt = f"""
    CRITICAL: Respond with ONLY a valid JSON object. No explanations, no markdown, no additional text.

    Extract date and service domain from this availability inquiry.
    Respond with ONLY this JSON format: {{"date": "DD-MM-YYYY", "domain": "service_type"}}

    Requirements:
    - Date: DD-MM-YYYY format (e.g., 04-08-2025)
    - Domain: Must be 'haircut', 'massage', or 'counselling'. Default to 'haircut' if not specified.
    
    Date conversions:
    - "tomorrow" = {(datetime.now() + timedelta(days=1)).strftime("%d-%m-%Y")}
    - "today" = {datetime.now().strftime("%d-%m-%Y")}
    - If no date found, use today: {datetime.now().strftime("%d-%m-%Y")}
    
    User input: {processed_input}

    Respond with ONLY the JSON object:
    """
    
    try:
        # ✅ USE DYNAMIC MODEL FROM STATE
        response = await extract_date_and_domain(prompt, selected_model)
        data = safe_json_loads(response.content, {"date": datetime.now().strftime("%d-%m-%Y"), "domain": "haircut"})
        
        date_str = data.get("date", datetime.now().strftime("%d-%m-%Y"))
        domain = data.get("domain", "haircut")
        
        logger.info(f"Extracted date: {date_str}, domain: {domain} in session {session_id} using model {selected_model}")
        
    except Exception as e:
        logger.error(f"Error extracting date/domain in session {session_id}: {str(e)}")
        
        # Use fallback values
        date_str = datetime.now().strftime("%d-%m-%Y")
        domain = "haircut"
        logger.info(f"Using fallback values - date: {date_str}, domain: {domain}")

    # Validate date format
    try:
        parsed_date = datetime.strptime(date_str, "%d-%m-%Y")
        # Check if date is in the past
        if parsed_date.date() < datetime.now().date():
            logger.info(f"Date {date_str} is in the past, using today's date in session {session_id}")
            date_str = datetime.now().strftime("%d-%m-%Y")
    except ValueError:
        logger.error(f"Invalid date format {date_str} in session {session_id}")
        date_str = datetime.now().strftime("%d-%m-%Y")
        logger.info(f"Using fallback date: {date_str}")
    
    # Load appointments for the specified date and domain
    try:
        appointments = load_appointments(date=date_str, domain=domain)
        logger.info(f"Loaded appointments for {date_str}, domain {domain}: {len(appointments.get(date_str, []))} bookings")
    except Exception as e:
        logger.error(f"Error loading appointments in session {session_id}: {str(e)}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": f"Error loading appointment data: {str(e)}"}],
            "next_agent": "end"
        }
    
    # Define available time slots (business hours)
    all_slots = get_available_time_slots(domain)
    booked_slots = [slot["time"] for slot in appointments.get(date_str, [])]
    available_slots = [slot for slot in all_slots if slot not in booked_slots]
    
    # Generate response with enhanced formatting
    try:
        response_text = generate_availability_response(date_str, domain, available_slots, booked_slots, all_slots)
        
        logger.info(f"Generated availability response for session {session_id} using model {selected_model}")
        
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": response_text}],
            "next_agent": "end"
        }
        
    except Exception as e:
        logger.error(f"Error generating response in session {session_id}: {str(e)}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": f"Error generating availability information: {str(e)}"}],
            "next_agent": "end"
        }

def preprocess_availability_input(user_input: str) -> str:
    """Preprocess user input to normalize date formats and common phrases"""
    user_input = user_input.lower().strip()
    
    # Normalize date separators
    user_input = re.sub(r'(\d{1,2})/(\d{1,2})/(\d{4})', r'\1-\2-\3', user_input)
    user_input = re.sub(r'(\d{1,2})\.(\d{1,2})\.(\d{4})', r'\1-\2-\3', user_input)
    
    # Handle relative dates
    today = datetime.now()
    if 'tomorrow' in user_input:
        tomorrow = today + timedelta(days=1)
        user_input = user_input.replace('tomorrow', tomorrow.strftime("%d-%m-%Y"))
    elif 'today' in user_input:
        user_input = user_input.replace('today', today.strftime("%d-%m-%Y"))
    
    # Normalize time-related phrases
    user_input = re.sub(r'\b(available|free|open)\s+(slots?|times?)\b', 'availability', user_input)
    user_input = re.sub(r'\bshow\s+me\b', 'check', user_input)
    
    logger.debug(f"Preprocessed input: {user_input}")
    return user_input

def get_available_time_slots(domain: str) -> list:
    """Get available time slots based on service domain"""
    # Different services might have different operating hours
    slot_configs = {
        "haircut": ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00"],
        "massage": ["10:00", "11:30", "13:00", "14:30", "16:00", "17:30"],
        "counselling": ["09:00", "10:30", "14:00", "15:30", "17:00"],
        "default": ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00"]
    }
    
    return slot_configs.get(domain, slot_configs["default"])

def generate_availability_response(date_str: str, domain: str, available_slots: list, 
                                 booked_slots: list, all_slots: list) -> str:
    """Generate a comprehensive availability response"""
    # Parse the date for better formatting
    try:
        parsed_date = datetime.strptime(date_str, "%d-%m-%Y")
        formatted_date = parsed_date.strftime("%A, %B %d, %Y")
    except:
        formatted_date = date_str
    
    if not available_slots:
        response = f"❌ **No Available Slots**\n\n"
        response += f"Unfortunately, all {domain} slots are booked for {formatted_date}.\n\n"
        if booked_slots:
            response += f"**Booked times:** {', '.join(sorted(booked_slots))}\n\n"
        
        # Suggest alternative dates
        suggestions = []
        for i in range(1, 4):  # Check next 3 days
            future_date = parsed_date + timedelta(days=i)
            future_date_str = future_date.strftime("%d-%m-%Y")
            try:
                future_appointments = load_appointments(date=future_date_str, domain=domain)
                future_booked = [slot["time"] for slot in future_appointments.get(future_date_str, [])]
                future_available = [slot for slot in all_slots if slot not in future_booked]
                
                if future_available:
                    suggestions.append(f"• {future_date.strftime('%A, %B %d')}: {len(future_available)} slots available")
            except:
                continue
        
        if suggestions:
            response += "**Alternative dates:**\n" + "\n".join(suggestions[:2])
        
        response += f"\n\n💡 *Try booking for a different date or consider our other services!*"
        
    else:
        response = f"✅ **Available {domain.title()} Slots**\n\n"
        response += f"📅 **Date:** {formatted_date}\n"
        response += f"🕐 **Available times:** {', '.join(sorted(available_slots))}\n"
        response += f"📊 **Availability:** {len(available_slots)}/{len(all_slots)} slots free\n\n"
        
        if booked_slots:
            response += f"⚠️ **Already booked:** {', '.join(sorted(booked_slots))}\n\n"
        
        # Add booking suggestion
        if available_slots:
            earliest_slot = min(available_slots)
            response += f"💡 *To book the earliest slot ({earliest_slot}), say:*\n"
            response += f"*\"Book a {domain} on {date_str} at {earliest_slot} for [Your Name]\"*"
    
    return response