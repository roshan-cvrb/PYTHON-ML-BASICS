# agents/confirmation_agent.py - Updated with Standard Logging (No Session Tracker)
from langchain_core.messages import AIMessage
from utils.llm import get_llm
from utils.database import load_appointments, save_appointment
from utils.json_parser import safe_json_loads
# REMOVED: session_tracker import
# UPDATED: Import SDK functions
from tracing.decorators import trace_agent, trace_llm_call
from tracing.trace_collector import configure_tracing_server, check_tracing_server
from datetime import datetime, timedelta
import json
from typing import Dict
import re
import logging
import os

# Setup consistent logging like dashapp.py
logger = logging.getLogger(__name__)

# CONFIGURE SDK FOR THIS AGENT
TRACING_SERVER_URL = os.getenv("TRACING_SERVER_URL", "http://localhost:8000")

# Initialize SDK (only configure once per agent)
try:
    configure_tracing_server(TRACING_SERVER_URL)
    if not check_tracing_server():
        logger.warning("⚠️ Tracing server not available for confirmation agent")
    else:
        logger.info("✅ Confirmation agent connected to tracing server")
except Exception as e:
    logger.warning(f"Could not initialize tracing SDK for confirmation agent: {str(e)}")

@trace_agent("confirmation", "booking_agent", framework="langgraph")
async def confirmation_agent(state: Dict) -> Dict:
    session_id = state.get("session_id", "unknown")
    messages = state["messages"]
    
    # ✅ GET DYNAMIC MODEL FROM STATE
    selected_model = state.get("model") or state.get("user_selected_model") or state.get("selected_model", "llama-3.3-70b-versatile")
    
    user_input = next((msg["content"] for msg in reversed(messages) if msg["role"] == "user"), None)
    
    if not user_input:
        logger.info(f"No user input provided for booking in session {session_id}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": "❌ No user input found. Please provide a booking request.\n\n💡 *Example: 'Book a haircut on 04-08-2025 at 10:00 for John Doe'*"}],
            "next_agent": "end",
            "pending_booking": {}
        }

    logger.info(f"Processing booking request in session {session_id} with model {selected_model}: {user_input}")
    
    # Preprocess input to normalize common variations
    processed_input = preprocess_booking_input(user_input)
    
    @trace_llm_call("booking_details_extraction", framework="langgraph")
    async def extract_booking_details(prompt: str, model: str):
        llm = get_llm(model)
        return await llm.ainvoke(prompt)
    
    # Enhanced LLM prompt for booking details extraction with stricter JSON format requirement
    prompt = f"""
    CRITICAL: You must respond with ONLY a valid JSON object. No explanations, no markdown, no additional text.

    Extract booking details from this appointment request and respond with ONLY this JSON format:
    {{"date": "DD-MM-YYYY", "time": "HH:MM", "name": "Full Name", "domain": "service_type"}}

    Requirements:
    - Date: DD-MM-YYYY format (e.g., 04-08-2025)
    - Time: HH:MM format in 24-hour time (e.g., 10:00, 14:30, 22:00)  
    - Name: Full name, remove possessive forms (e.g., "John Doe's" → "John Doe")
    - Domain: Must be 'haircut', 'massage', or 'counselling'. Default to 'haircut' if not specified.
    
    Time conversions:
    - 12AM = 00:00, 1AM = 01:00, ..., 11AM = 11:00
    - 12PM = 12:00, 1PM = 13:00, ..., 11PM = 23:00
    
    Date conversions:
    - "tomorrow" = {(datetime.now() + timedelta(days=1)).strftime("%d-%m-%Y")}
    - "today" = {datetime.now().strftime("%d-%m-%Y")}
    - Convert month names to numbers, ensure DD-MM-YYYY format
    
    If ANY required field is missing (date, time, or name), respond with:
    {{"error": "Missing required booking details"}}

    User input: {processed_input}

    Respond with ONLY the JSON object:
    """

    logger.info(f"Sending booking extraction request to LLM in session {session_id} using model {selected_model}")
    
    try:
        # ✅ USE DYNAMIC MODEL FROM STATE
        response = await extract_booking_details(prompt, selected_model)
        logger.info(f"LLM response in session {session_id}: {response.content}")
        
        # Use robust JSON parsing
        data = safe_json_loads(response.content, {"error": "Could not parse booking details"})
        
        if "error" in data:
            logger.info(f"Invalid booking details in session {session_id}: {data['error']}")
            
            error_response = generate_booking_error_response(data['error'], user_input)
            return {
                **state,
                "messages": messages + [{"role": "assistant", "content": error_response}],
                "next_agent": "end",
                "pending_booking": {}
            }
        else:
            date_str = data.get("date", "")
            time_str = data.get("time", "")
            name = data.get("name", "").strip().rstrip("'s")
            domain = data.get("domain", "haircut")
            
    except Exception as e:
        logger.error(f"Error in LLM request for session {session_id}: {str(e)}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": f"❌ **Error processing request:** {str(e)}\n\n{generate_booking_help_message()}"}],
            "next_agent": "end",
            "pending_booking": {}
        }

    logger.info(f"Extracted details in session {session_id} using model {selected_model} - Date: {date_str}, Time: {time_str}, Name: {name}, Domain: {domain}")

    # Validate extracted details
    validation_result = validate_booking_details(date_str, time_str, name, domain, session_id)
    if not validation_result["valid"]:
        logger.info(f"Validation failed in session {session_id}: {validation_result['error']}")
        
        error_response = generate_booking_error_response(validation_result['error'], user_input)
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": error_response}],
            "next_agent": "end",
            "pending_booking": {}
        }

    # Check slot availability
    try:
        availability_check = check_slot_availability(date_str, time_str, domain, session_id)
        
        if not availability_check["available"]:
            logger.info(f"Slot not available in session {session_id}: {availability_check['message']}")
            
            unavailable_response = generate_unavailable_response(date_str, time_str, domain, availability_check)
            return {
                **state,
                "messages": messages + [{"role": "assistant", "content": unavailable_response}],
                "next_agent": "end",
                "pending_booking": {}
            }

        # Attempt to save the appointment
        logger.info(f"Saving booking for {name} on {date_str} at {time_str}, domain {domain} in session {session_id}")
        
        appointment_id = save_appointment(date_str, time_str, name, domain)
        
        if appointment_id:
            # Booking successful
            success_response = generate_booking_success_response(appointment_id, date_str, time_str, name, domain)
            
            logger.info(f"Successfully booked appointment {appointment_id} in session {session_id} using model {selected_model}")
            
            return {
                **state,
                "messages": messages + [{"role": "assistant", "content": success_response}],
                "next_agent": "end",
                "pending_booking": {}
            }
            
        else:
            # Booking failed
            failure_response = generate_booking_failure_response(date_str, time_str, name, domain)
            
            logger.error(f"Failed to save booking in session {session_id}")
            
            return {
                **state,
                "messages": messages + [{"role": "assistant", "content": failure_response}],
                "next_agent": "end",
                "pending_booking": {}
            }

    except Exception as e:
        logger.error(f"Error during booking process in session {session_id}: {str(e)}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": f"❌ Error during booking process: {str(e)}"}],
            "next_agent": "end",
            "pending_booking": {}
        }

# Helper functions (keeping all existing ones with removed log_action calls)
def preprocess_booking_input(user_input: str) -> str:
    """Preprocess user input to normalize common booking variations"""
    processed = user_input.lower().strip()
    
    # Normalize booking keywords
    processed = re.sub(r'\b(book|schedule|reserve|make)\s+(an?\s+)?appointment\b', 'book appointment', processed)
    processed = re.sub(r'\bset\s+up\s+appointment\b', 'book appointment', processed)
    processed = re.sub(r'\bi\s+(want|need|would\s+like)\s+(a\s+)?\b', 'book ', processed)
    
    # Normalize time separators and formats
    processed = re.sub(r'\s*at\s+', ' ', processed)
    processed = re.sub(r'(\d{1,2}):(\d{2})', r'\1:\2', processed)
    
    # Normalize date separators
    processed = re.sub(r'(\d{1,2})[/.](\d{1,2})[/.](\d{2,4})', r'\1-\2-\3', processed)
    
    # Normalize name indicators
    processed = re.sub(r'\b(for|name:?|my\s+name\s+is)\s+', 'name ', processed)
    
    logger.debug(f"Preprocessed booking input: '{user_input}' -> '{processed}'")
    return processed

def validate_booking_details(date_str: str, time_str: str, name: str, domain: str, session_id: str) -> dict:
    """Comprehensive validation of all booking details"""
    
    # Validate date
    try:
        if not date_str:
            return {"valid": False, "error": "Date is required. Please specify when you'd like your appointment."}
        
        parsed_date = datetime.strptime(date_str, "%d-%m-%Y")
        
        # Check if date is in the past
        if parsed_date.date() < datetime.now().date():
            return {"valid": False, "error": f"Cannot book appointments in the past. Date {date_str} has already passed."}
        
        # Check if date is too far in the future (e.g., more than 6 months)
        max_future_date = datetime.now() + timedelta(days=180)
        if parsed_date > max_future_date:
            return {"valid": False, "error": f"Cannot book appointments more than 6 months in advance. Please choose an earlier date."}
            
    except ValueError:
        return {"valid": False, "error": f"Invalid date format: '{date_str}'. Please use DD-MM-YYYY format (e.g., 04-08-2025)."}
    
    # Validate time
    try:
        if not time_str:
            return {"valid": False, "error": "Time is required. Please specify what time you'd like your appointment."}
        
        parsed_time = datetime.strptime(time_str, "%H:%M")
        hour = parsed_time.hour
        
        # Check business hours (9 AM to 6 PM)
        if hour < 9 or hour >= 18:
            return {"valid": False, "error": f"Appointments are only available between 09:00 and 18:00. Please choose a time within business hours."}
            
    except ValueError:
        return {"valid": False, "error": f"Invalid time format: '{time_str}'. Please use HH:MM format (e.g., 10:00, 14:30)."}
    
    # Validate name
    if not name or len(name.strip()) < 2:
        return {"valid": False, "error": "Valid name is required. Please provide your full name (e.g., 'John Doe')."}
    
    if len(name) > 50:
        return {"valid": False, "error": "Name is too long. Please provide a shorter name (maximum 50 characters)."}
    
    # Validate name format (basic check for reasonable characters)
    if not re.match(r'^[a-zA-Z\s\'-]+$', name):
        return {"valid": False, "error": "Name contains invalid characters. Please use only letters, spaces, apostrophes, and hyphens."}
    
    # Validate domain
    valid_domains = ['haircut', 'massage', 'counselling']
    if domain not in valid_domains:
        logger.warning(f"Unknown domain '{domain}' in session {session_id}, defaulting to 'haircut'")
        domain = 'haircut'
    
    logger.info(f"All booking details validated successfully in session {session_id}")
    return {"valid": True, "error": None}

def check_slot_availability(date_str: str, time_str: str, domain: str, session_id: str) -> dict:
    """Check if the requested time slot is available"""
    try:
        appointments = load_appointments(date=date_str, domain=domain)
        booked_slots = appointments.get(date_str, [])
        
        # Check for exact time conflict
        for booking in booked_slots:
            if booking["time"] == time_str:
                return {
                    "available": False,
                    "message": f"Slot {time_str} on {date_str} is already booked for {domain}",
                    "conflicting_booking": booking
                }
        
        logger.info(f"Slot {time_str} on {date_str} is available for {domain} in session {session_id}")
        return {"available": True, "message": "Slot is available"}
        
    except Exception as e:
        logger.error(f"Error checking slot availability in session {session_id}: {str(e)}")
        return {
            "available": False,
            "message": f"Error checking availability: {str(e)}"
        }

def generate_booking_error_response(error_message: str, user_input: str) -> str:
    """Generate a helpful error response for booking issues"""
    response = f"❌ **Booking Error**\n\n{error_message}\n\n"
    response += generate_booking_help_message()
    return response

def generate_booking_help_message() -> str:
    """Generate a helpful message explaining how to book appointments"""
    return """💡 **How to book an appointment:**

**Required Information:**
• 📅 Date (DD-MM-YYYY format)
• 🕐 Time (HH:MM format, 9 AM - 6 PM)  
• 👤 Your full name
• 🏷️ Service type (haircut/massage/counselling)

**Example bookings:**
• "Book a haircut on 04-08-2025 at 10:00 for John Doe"
• "Schedule massage appointment tomorrow at 14:30 for Sarah Johnson"
• "Reserve counselling slot on 15-08-2025 at 11:00 for Mike Wilson"

**Available Services:** Haircut, Massage, Counselling
**Business Hours:** 9:00 AM - 6:00 PM, Monday to Saturday"""

def generate_unavailable_response(date_str: str, time_str: str, domain: str, availability_check: dict) -> str:
    """Generate response when requested slot is not available"""
    formatted_date = format_date_display(date_str)
    
    response = f"❌ **Slot Not Available**\n\n"
    response += f"The {domain} appointment at **{time_str}** on **{formatted_date}** is already booked.\n\n"
    
    # Try to suggest alternative times
    try:
        alternative_times = get_alternative_times(date_str, time_str, domain)
        if alternative_times:
            response += "**🕐 Alternative times available on the same day:**\n"
            for alt_time in alternative_times[:3]:  # Show max 3 alternatives
                response += f"• {alt_time}\n"
            response += f"\n💡 *Say: 'Book {domain} on {date_str} at [time] for [your name]'*"
        else:
            response += f"**😔 No other slots available on {formatted_date}**\n\n"
            response += "💡 *Try checking availability for other dates or services.*"
    except:
        response += "💡 *Please try a different time or date.*"
    
    return response

def generate_booking_success_response(appointment_id: int, date_str: str, time_str: str, name: str, domain: str) -> str:
    """Generate a comprehensive success response for confirmed booking"""
    formatted_date = format_date_display(date_str)
    
    response = f"✅ **Booking Confirmed!** 🎉\n\n"
    response += f"**📋 Appointment Details:**\n"
    response += f"• 🆔 **ID:** {appointment_id}\n"
    response += f"• 📅 **Date:** {formatted_date}\n"
    response += f"• 🕐 **Time:** {time_str}\n"
    response += f"• 👤 **Name:** {name}\n"
    response += f"• 🏷️ **Service:** {domain.title()}\n\n"
    
    # Add helpful reminders and next steps
    response += f"**📝 Important Notes:**\n"
    response += f"• Please arrive 5-10 minutes early\n"
    response += f"• Save your appointment ID: **{appointment_id}**\n"
    response += f"• To cancel, provide your appointment details\n\n"
    
    response += f"**🎯 What's Next?**\n"
    response += f"• Check availability: *'Show free slots on [date]'*\n"
    response += f"• Book another: *'Book [service] on [date] at [time] for [name]'*\n"
    response += f"• Cancel if needed: *'Cancel appointment on {date_str} at {time_str} for {name}'*\n\n"
    
    response += f"**Thank you for booking with us!** 😊"
    
    return response

def generate_booking_failure_response(date_str: str, time_str: str, name: str, domain: str) -> str:
    """Generate response when booking fails to save"""
    formatted_date = format_date_display(date_str)
    
    response = f"❌ **Booking Failed**\n\n"
    response += f"We couldn't save your {domain} appointment for **{name}** on **{formatted_date}** at **{time_str}**.\n\n"
    response += f"**Please try:**\n"
    response += f"• Booking again in a few moments\n"
    response += f"• Choosing a different time slot\n"
    response += f"• Contacting support if the problem persists\n\n"
    response += f"💡 *We apologize for the inconvenience!*"
    
    return response

def get_alternative_times(date_str: str, requested_time: str, domain: str) -> list:
    """Get alternative available times for the same date and domain"""
    try:
        appointments = load_appointments(date=date_str, domain=domain)
        booked_slots = appointments.get(date_str, [])
        booked_times = [slot["time"] for slot in booked_slots]
        
        # Define available time slots for the domain
        all_slots = get_business_hours_slots(domain)
        available_slots = [slot for slot in all_slots if slot not in booked_times]
        
        # Sort by proximity to requested time
        requested_hour = int(requested_time.split(':')[0])
        available_slots.sort(key=lambda x: abs(int(x.split(':')[0]) - requested_hour))
        
        return available_slots
        
    except Exception as e:
        logger.error(f"Error getting alternative times: {str(e)}")
        return []

def get_business_hours_slots(domain: str) -> list:
    """Get available time slots based on business hours and service type"""
    slot_configs = {
        "haircut": ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"],
        "massage": ["09:00", "10:30", "12:00", "13:30", "15:00", "16:30"],  # 90-min slots
        "counselling": ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00"],  # No lunch sessions
        "default": ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00"]
    }
    
    return slot_configs.get(domain, slot_configs["default"])

def format_date_display(date_str: str) -> str:
    """Format date string for better display in responses"""
    try:
        parsed_date = datetime.strptime(date_str, "%d-%m-%Y")
        return parsed_date.strftime("%A, %B %d, %Y")
    except:
        return date_str