# agents/supervisor_agent.py - Updated with Standard Logging (No Session Tracker)
from langchain_core.messages import AIMessage
from utils.llm import get_llm
# REMOVED: session_tracker import
# UPDATED: Import SDK functions
from tracing.decorators import trace_agent, trace_llm_call
from tracing.trace_collector import configure_tracing_server, check_tracing_server
from typing import Dict, List
import logging
import re
import os

# Setup consistent logging like dashapp.py
logger = logging.getLogger(__name__)

# CONFIGURE SDK FOR THIS AGENT
TRACING_SERVER_URL = os.getenv("TRACING_SERVER_URL", "http://localhost:8000")

# Initialize SDK (only configure once per process)
try:
    configure_tracing_server(TRACING_SERVER_URL)
    if not check_tracing_server():
        logger.warning("⚠️ Tracing server not available for supervisor agent")
    else:
        logger.info("✅ Supervisor agent connected to tracing server")
except Exception as e:
    logger.warning(f"Could not initialize tracing SDK: {str(e)}")

@trace_agent("supervisor", "routing_agent", framework="langgraph")
async def supervisor_agent(state: Dict) -> Dict:
    session_id = state.get("session_id", "unknown")
    messages = state["messages"]
    
    # ✅ GET DYNAMIC MODEL FROM STATE
    selected_model = state.get("model") or state.get("user_selected_model") or state.get("selected_model", "llama-3.3-70b-versatile")
    
    # Find the latest user message
    user_input = next((msg["content"] for msg in reversed(messages) if msg["role"] == "user"), None)
    if not user_input:
        logger.info(f"No user input found in session {session_id}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": "❌ No user input found. Please tell me how I can help you with appointments."}], 
            "next_agent": "end"
        }
    
    logger.info(f"Processing user input in session {session_id} with model {selected_model}: {user_input}")
    
    # Preprocess input for better intent detection
    processed_input = preprocess_supervisor_input(user_input)
    
    # Check for exit conditions first
    if is_exit_intent(user_input):
        logger.info(f"Exit intent detected in session {session_id}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": "👋 Thank you for using our appointment system! Have a great day!"}],
            "next_agent": "end"
        }
    
    # Check for greeting or help requests
    if is_greeting_or_help(user_input):
        logger.info(f"Greeting/help intent detected in session {session_id}")
        help_response = generate_help_response()
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": help_response}],
            "next_agent": "end"
        }
    
    @trace_llm_call("intent_classification", framework="langgraph")
    async def classify_intent(prompt: str, model: str):
        llm = get_llm(model)
        return await llm.ainvoke(prompt)
    
    # Enhanced intent detection prompt
    prompt = f"""
    You are a supervisor agent for an appointment booking system. Analyze the user's input and determine which specialized agent should handle the request.

    User input: "{processed_input}"

    Available agents and their purposes:
    
    1. **availability** - For checking available time slots, schedules, or free appointments
       Examples: "check availability", "show free slots", "what times are available", "when can I book"
    
    2. **confirmation** - For booking, scheduling, or confirming new appointments
       Examples: "book appointment", "schedule haircut", "reserve slot", "make appointment"
    
    3. **cancellation** - For canceling, removing, or deleting existing appointments
       Examples: "cancel appointment", "remove booking", "delete reservation", "cancel my slot"
    
    4. **end** - If the request is unclear, complete, or doesn't fit the above categories
       Examples: unclear requests, greetings already handled, or conversation completion
    
    Respond with ONLY the agent name: availability, confirmation, cancellation, or end
    """
    
    try:
        # ✅ USE DYNAMIC MODEL FROM STATE
        response = await classify_intent(prompt, selected_model)
        next_agent = response.content.strip().lower()
        
        logger.info(f"LLM classified intent as '{next_agent}' in session {session_id} using model {selected_model}")
        
    except Exception as e:
        logger.error(f"Error in LLM request for session {session_id}: {str(e)}")
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": f"❌ Error processing your request: {str(e)}\n\n💡 Please try again or be more specific about what you'd like to do."}],
            "next_agent": "end"
        }
    
    # Validate and route to appropriate agent
    routing_result = validate_and_route_intent(next_agent, user_input, session_id)
    
    if routing_result["valid"]:
        next_agent = routing_result["agent"]
        routing_message = routing_result["message"]
        
        logger.info(f"Successfully routing to {next_agent} agent in session {session_id}")
        
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": routing_message}],
            "next_agent": next_agent
        }
    else:
        # Invalid routing - provide clarification
        clarification_message = generate_clarification_message(user_input)
        logger.warning(f"Invalid routing, requesting clarification in session {session_id}")
        
        return {
            **state,
            "messages": messages + [{"role": "assistant", "content": clarification_message}],
            "next_agent": "end"
        }

def preprocess_supervisor_input(user_input: str) -> str:
    """Preprocess user input to normalize common variations and improve intent detection"""
    processed = user_input.lower().strip()
    
    # Normalize common booking phrases
    booking_patterns = [
        (r'\b(book|schedule|reserve|make)\s+(an?\s+)?appointment\b', 'book appointment'),
        (r'\b(book|schedule|reserve)\s+(a\s+)?(haircut|massage|counselling)\b', r'book \3'),
        (r'\bset\s+up\s+appointment\b', 'book appointment'),
        (r'\bi\s+(want|need)\s+(a\s+)?(haircut|massage|counselling)\b', r'book \3'),
    ]
    
    # Normalize cancellation phrases
    cancellation_patterns = [
        (r'\b(cancel|remove|delete)\s+(the\s+|my\s+)?appointment\b', 'cancel appointment'),
        (r'\b(cancel|remove|delete)\s+(the\s+|my\s+)?(booking|reservation)\b', 'cancel appointment'),
        (r'\bcancel\s+(my\s+)?(haircut|massage|counselling)\b', 'cancel appointment'),
    ]
    
    # Normalize availability phrases
    availability_patterns = [
        (r'\b(check|show|what)\s+(available|free)\s+(slots?|times?)\b', 'check availability'),
        (r'\bwhen\s+(can\s+i|are\s+you)\s+(available|free)\b', 'check availability'),
        (r'\bshow\s+me\s+(available|free|open)\b', 'check availability'),
        (r'\bavailability\s+(on|for)\b', 'check availability'),
    ]
    
    # Apply normalization patterns
    for patterns in [booking_patterns, cancellation_patterns, availability_patterns]:
        for pattern, replacement in patterns:
            processed = re.sub(pattern, replacement, processed, flags=re.IGNORECASE)
    
    logger.debug(f"Preprocessed input: '{user_input}' -> '{processed}'")
    return processed

def is_exit_intent(user_input: str) -> bool:
    """Check if user wants to exit the conversation"""
    exit_phrases = [
        'exit', 'quit', 'bye', 'goodbye', 'good bye', 'see you', 'thanks bye',
        'that\'s all', 'nothing else', 'done', 'finished', 'stop', 'end'
    ]
    
    user_lower = user_input.lower().strip()
    return any(phrase in user_lower for phrase in exit_phrases)

def is_greeting_or_help(user_input: str) -> bool:
    """Check if user is greeting or asking for help"""
    greeting_phrases = [
        'hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening',
        'help', 'what can you do', 'how does this work', 'commands', 'options'
    ]
    
    user_lower = user_input.lower().strip()
    return any(phrase in user_lower for phrase in greeting_phrases) and len(user_input.split()) <= 5

def generate_help_response() -> str:
    """Generate a comprehensive help response"""
    return """👋 **Welcome to the AI Appointment Assistant!**

I can help you with the following:

**📅 Check Availability**
• "Show available slots on 04-08-2025"
• "Check availability for massage this week"
• "What times are free on Monday?"

**✅ Book Appointments** 
• "Book a haircut on 04-08-2025 at 10:00 for John Doe"
• "Schedule massage appointment for tomorrow 2PM, name Sarah"
• "Reserve counselling slot on 15-08-2025 at 14:30 for Mike"

**❌ Cancel Appointments**
• "Cancel appointment on 04-08-2025 at 10:00 for John Doe"
• "Remove my haircut booking tomorrow at 2PM"
• "Delete reservation for Sarah on 15-08-2025"

**💡 Available Services:**
• Haircut appointments
• Massage therapy sessions  
• Counselling appointments

Just tell me what you'd like to do in natural language! 🎯"""

def validate_and_route_intent(next_agent: str, user_input: str, session_id: str) -> dict:
    """Validate the routing decision and provide appropriate messaging"""
    
    valid_agents = ["availability", "confirmation", "cancellation", "end"]
    
    if next_agent not in valid_agents:
        logger.warning(f"Invalid agent '{next_agent}' suggested by LLM in session {session_id}")
        return {
            "valid": False,
            "agent": "end",
            "message": "❌ Unable to determine your intent. Please be more specific."
        }
    
    # Generate appropriate routing messages
    routing_messages = {
        "availability": "🔍 **Checking Availability**\n\nLet me find the available appointment slots for you...",
        "confirmation": "📝 **Processing Booking Request**\n\nI'll help you book your appointment...",
        "cancellation": "❌ **Processing Cancellation**\n\nLet me cancel your appointment...",
        "end": "✅ **Request Complete**\n\nIs there anything else I can help you with?"
    }
    
    return {
        "valid": True,
        "agent": next_agent,
        "message": routing_messages.get(next_agent, "Processing your request...")
    }

def generate_clarification_message(user_input: str) -> str:
    """Generate a helpful clarification message when intent is unclear"""
    
    message = "❓ **I'm not sure what you'd like to do.**\n\n"
    
    message += """**What would you like to do?**

🔍 **Check availability:** "Show free slots on 04-08-2025"
📝 **Book appointment:** "Book haircut on 04-08-2025 at 10:00 for John"  
❌ **Cancel appointment:** "Cancel my appointment on 04-08-2025 at 10:00"

💡 *Just tell me what you want to do and I'll help you!*"""
    
    return message