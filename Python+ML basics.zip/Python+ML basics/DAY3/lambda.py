add =lambda x,y : x+y
print(add(10,20))


d=[
    {'id': '101', 'name': 'Roshan', 'course': 'Python', 'score': '90'}, 
    {'id': '102', 'name': 'Shaman', 'course': 'Java', 'score': '85'}, 
    {'id': '103', 'name': 'Akhilesh', 'course': 'C++', 'score': '95'}
]
sorted_list = sorted(d, key=lambda x: x['score'], reverse=True)