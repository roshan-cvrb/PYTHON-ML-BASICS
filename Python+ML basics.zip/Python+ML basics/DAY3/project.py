import os

class Student:
    d = {}
    def __init__(self, s_id, s_name, s_course, s_score, save=True):
        self.id = s_id
        self.name = s_name
        self.course = s_course
        self.score = s_score
        Student.d[self.id] = self
        if save:
            save_to_txt()

    def add(self):
        print(f"s_id : {self.id}")
        print(f"s_name: {self.name}")
        print(f"s_course: {self.course}")
        print(f"s_score: {self.score}")
        save_to_txt()
        print("*" * 20)

    def view(self):
        print(f"s_id : {self.id}")
        print(f"s_name: {self.name}")
        print(f"s_course: {self.course}")
        print(f"s_score: {self.score}")
        print("*" * 20)

    def update(self, new_name=None, new_course=None, new_score=None):
        if new_name:
            self.name = new_name
        if new_course:
            self.course = new_course
        if new_score:
            self.score = new_score
        Student.d[self.id] = self
        save_to_txt()
        print(f"Student with id {self.id} updated successfully")
        print(f"s_name: {self.name}")
        print(f"s_course: {self.course}")
        print(f"s_score: {self.score}")
        print("*" * 20)

    def delete(self):
        del Student.d[self.id]
        save_to_txt()
        print(f"Student with id {self.id} deleted")
        print("*" * 20)

def save_to_txt():
    with open("students.txt", "w") as f:
        f.write("s_id,s_name,s_course,s_score\n")
        for s in Student.d.values():
            f.write(f"{s.id},{s.name},{s.course},{s.score}\n")

if __name__ == "__main__":

    while True:
        choice = input("Enter your choice (add/view/update/delete/exit): ")
        if choice == "add":
            s_id = input("Enter id: ")
            s_name = input("Enter name: ")
            s_course = input("Enter course: ")
            s_score = input("Enter score: ")
            student = Student(s_id, s_name, s_course, s_score)
            student.add()
        elif choice == "view":
            s_id = input("Enter id: ")
            if s_id in Student.d:
                student = Student.d[s_id]
                student.view()
            else:
                print(f"s_id: {s_id} not found")
        elif choice == "update":
            s_id = input("Enter id: ")
            if s_id in Student.d:
                student = Student.d[s_id]
                new_name = input("Enter New Name (leave blank to keep current): ")
                new_course = input("Enter New Course (leave blank to keep current): ")
                new_score = input("Enter New Score (leave blank to keep current): ")
                student.update(
                    new_name if new_name else None,
                    new_course if new_course else None,
                    new_score if new_score else None
                )
            else:
                print(f"s_id: {s_id} not found")
        elif choice == "delete":
            s_id = input("Enter id: ")
            if s_id in Student.d:
                student = Student.d[s_id]
                student.delete()
            else:
                print(f"s_id: {s_id} not found")
        elif choice == "exit":
            break
        else:
            print("Invalid choice")