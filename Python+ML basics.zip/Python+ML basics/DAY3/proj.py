import os

class Student:
    __d = {}

    def __init__(self, s_id, s_name, s_course, s_score, save=True):
        self.__id = s_id
        self.__name = s_name
        self.__course = s_course
        self.__score = s_score
        Student.__d[self.__id] = self
        if save:
            with open("students.txt", "w") as f:
                f.write("s_id,s_name,s_course,s_score\n")
                for s in all_students():
                    f.write(f"{s._Student__id},{s._Student__name},{s._Student__course},{s._Student__score}\n")

    def add(self):
        print(f"s_id : {self.__id}")
        print(f"s_name: {self.__name}")
        print(f"s_course: {self.__course}")
        print(f"s_score: {self.__score}")
        with open("students.txt", "w") as f:
            f.write("s_id,s_name,s_course,s_score\n")
            for s in all_students():
                f.write(f"{s._Student__id},{s._Student__name},{s._Student__course},{s._Student__score}\n")
        print("*" * 20)

    def view(self):
        print(f"s_id : {self.__id}")
        print(f"s_name: {self.__name}")
        print(f"s_course: {self.__course}")
        print(f"s_score: {self.__score}")
        print("*" * 20)

    def update(self, new_name=None, new_course=None, new_score=None):
        if new_name:
            self.__name = new_name
        if new_course:
            self.__course = new_course
        if new_score:
            self.__score = new_score
        Student.__d[self.__id] = self
        with open("students.txt", "w") as f:
            f.write("s_id,s_name,s_course,s_score\n")
            for s in all_students():
                f.write(f"{s._Student__id},{s._Student__name},{s._Student__course},{s._Student__score}\n")
        print(f"Student with id {self.__id} updated successfully")
        print(f"s_name: {self.__name}")
        print(f"s_course: {self.__course}")
        print(f"s_score: {self.__score}")
        print("*" * 20)

    def delete(self):
        del Student.__d[self.__id]
        with open("students.txt", "w") as f:
            f.write("s_id,s_name,s_course,s_score\n")
            for s in all_students():
                f.write(f"{s._Student__id},{s._Student__name},{s._Student__course},{s._Student__score}\n")
        print(f"Student with id {self.__id} deleted")
        print("*" * 20)

def get_student(s_id):
    return Student._Student__d.get(s_id)

def all_students():
    return Student._Student__d.values()

#def save_to_txt():
    #with open("students.txt", "w") as f:
        #f.write("s_id,s_name,s_course,s_score\n")
        #for s in all_students():
            #f.write(f"{s._Student__id},{s._Student__name},{s._Student__course},{s._Student__score}\n")

class StudentManagementSystem(Student):
    def __init__(self, s_id, s_name, s_course, s_score):
        super().__init__(s_id, s_name, s_course, s_score)

    def display_student(self):
        print(f"Student Info: {self._Student__id}, {self._Student__name}, {self._Student__course}, {self._Student__score}")

# Example usage and menu
if __name__ == "__main__":
    while True:
        choice = input("Enter your choice (add/view/update/delete/exit): ")
        if choice == "add":
            s_id = input("Enter id: ")
            s_name = input("Enter name: ")
            s_course = input("Enter course: ")
            s_score = input("Enter score: ")
            student = StudentManagementSystem(s_id, s_name, s_course, s_score)
            student.add()
        elif choice == "view":
            s_id = input("Enter id: ")
            student = get_student(s_id)
            if student:
                student.view()
            else:
                print(f"s_id: {s_id} not found")
        elif choice == "update":
            s_id = input("Enter id: ")
            student = get_student(s_id)
            if student:
                new_name = input("Enter New Name (leave blank to keep current): ")
                new_course = input("Enter New Course (leave blank to keep current): ")
                new_score = input("Enter New Score (leave blank to keep current): ")
                student.update(
                    new_name if new_name else None,
                    new_course if new_course else None,
                    new_score if new_score else None
                )
            else:
                print(f"s_id: {s_id} not found")
        elif choice == "delete":
            s_id = input("Enter id: ")
            student = get_student(s_id)
            if student:
                student.delete()
            else:
                print(f"s_id: {s_id} not found")
        elif choice == "exit":
            break
        else:
            print("Invalid choice")