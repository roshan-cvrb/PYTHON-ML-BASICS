class BankDetails:
    def __init__(self,acc_no,acc_name,acc_bal):
        self.acc_no=acc_no
        self.acc_name=acc_name
        self.acc_bal=acc_bal
    def display(self):
        print(f"Account Number: {self.acc_no}")
        print(f"Account Name: {self.acc_name}")
        print(f"Account Balance: {self.acc_bal}")
        print("*"*20)
    def __eq__(self,other):
        return self.acc_bal==other.acc_bal
    
if __name__=="__main__":
    b1=BankDetails("123456789","Roshan",10000)
    b2=BankDetails("987654321","Shaman",10000)
    b1.display()
    b2.display()
    #print(b1.__eq__(b2))
    print(f"Are balances equal? {b1==b2}")
    
