'''class Product:
    #constructor
    def __init__(self,prdid,prdname,prdprice,prdquantity):
        self.id = prdid
        self.name = prdname
        self.price = prdprice
        self.quantity = prdquantity
        self.total = prdprice * prdquantity
    def display(self):
        print(f"Product ID: {self.id}")
        print(f"Product Name: {self.name}")
        print(f"Product Price: {self.price}")
        print(f"Product Quantity: {self.quantity}")
        print(f"Product Total: {self.total}")
        

if __name__ == "__main__":
    P1 = Product(101,"Laptop",50000,10)
    P2 = Product(102,"Mobile",20000,20)
    P1.display()
    P2.display()'''

class Car:
    def __init__(self, car_brand, car_model, car_price):
        self.name = car_brand
        self.model = car_model
        self.price = car_price

    def display(self):
        print(f"Car Name: {self.name}")
        print(f"Car Model: {self.model}")
        print(f"Car Price: {self.price}")
        print("***************")

if __name__ == "__main__":
    car1 = Car("Toyota", "Camry", "$30000")
    car2 = Car("Honda", "Civic", "$25000")
    car3 = Car("Ford", "Mustang", "$55000")

    car1.display()
    car2.display()
    car3.display()