#polymorphism can be achieved by method overriding and duck typing(Dynamic typing)
#Method Overriding-method in child class has same name as method in parent class
#Duck typing-If an object behaves like a certain type, it can be treated as that type
#Duck typing is a concept in dynamic programming languages where the type or class of an object is less important than the methods it defines and the way it behaves.
class Trainer:
    def getrole(self):
        print("Trainer teaches the students")

class Student:
    def getrole(self):
        print("Student learns from the trainer")

class Admin:
    def getrole(self):
        print("Admin manages the system")

def getrole(obj):
    obj.getrole()

ch=input("Enter the role (Trainer/Student/Admin): ")
if ch=="Trainer":
    getrole(Trainer())
elif ch=="Student":
    getrole(Student())
elif ch=="Admin":
    getrole(Admin())
else:
    print("Invalid role")