class Car:
    car_brand=input("Enter Car Brand:")
    def __init__(self,car_model,car_price):
        self.model=car_model
        self.price=car_price
    def display(self):
        print(f"Car Brand: {Car.car_brand}")
        print(f"Car Model: {self.model}")
        print(f"Car Price: {self.price}")
        print("***************")
if __name__ == "__main__":
    car1=Car("Swift","Rs.600000")
    car2=Car("Venue","Rs.1600000")
    car3=Car("Seltos","Rs.2000000")
    car1.display()
    car2.display()
    car3.display()