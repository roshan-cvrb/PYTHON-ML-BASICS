class Employee:
    company_name="Altimetrik Pvt Ltd"
    def __init__(self, emp_id, emp_name,emp_dept, emp_salary):
        self.id = emp_id
        self.name = emp_name
        self.dept=emp_dept
        self.salary = emp_salary
    
    def display(self):
        print(f"Company Name: {Employee.company_name}")
        print(f"Employee ID: {self.id}")
        print(f"Employee Name: {self.name}")
        print(f"Employee Department: {self.dept}")
        print(f"Employee Salary: {self.salary}")
        print("***************")
        
    def annual_salary(self):
        return self.salary * 12
    
    def apply_increment(self, percentage):
        increment = (self.salary * percentage) / 100
        self.salary += increment
        print(f"New Salary after {percentage}% increment: {self.salary}")
    
    def highest_salary(self, other):
        if self.salary > other.salary:
            print(f"{self.name} has a higher salary than {other.name}")
        elif self.salary < other.salary:
            print(f"{other.name} has a higher salary than {self.name}")
        else:
            print(f"{self.name} and {other.name} have the same salary")
    def is_higher_earner(self):
        if self.salary > 50000:
            return True
        else:
            return False
    @staticmethod
    def company_info():
        print(f"Company Name: {Employee.company_name}")
        print("***************")

if __name__ == "__main__":
    Employee.company_info()
    emp1 = Employee(101, "Roshan", "DS", 60000)
    emp2 = Employee(102, "Akhilesh", "DS", 70000)
    emp3 = Employee(103, "Vanmeeganathan", "DS", 80000)

    emp1.display()
    emp2.display()
    emp3.display()

    emp1.apply_increment(10)
    emp2.apply_increment(15)
    emp3.apply_increment(20)
    
    emp1.is_higher_earner()
    emp2.is_higher_earner()

    emp1.highest_salary(emp2)
    emp2.highest_salary(emp3)
    Employee.company_info()