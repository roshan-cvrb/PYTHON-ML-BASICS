#abstraction is the process of hiding the implementation details and showing only the functionality to the user.

#encapsulation is the bundling of data with the methods that operate on that data.


class Product:
    def __init__(self, prdid, prdname, prdprice, prdquantity):
        self.__id = prdid
        self.__name = prdname
        self._price = prdprice
        self.__quantity = prdquantity
        self.__total = prdprice * prdquantity

    def display(self):
        print(f"Product ID: {self.__id}")
        print(f"Product Name: {self.__name}")
        print(f"Product Price: {self._price}")
        print(f"Product Quantity: {self.__quantity}")
        print(f"Product Total: {self.__total}")
        
if __name__ == "__main__":
    P1 = Product(101, "Laptop", 50000, 10)
    P2 = Product(102, "Mobile", 20000, 20)
    P1.display()
    P2.display()
    
    
class BankDetails:
    def __init__(self, account_number, name, balance):
        self.__account_number = account_number
        self.name = name
        self._balance = balance

    def get_account_number(self):
        return self.__account_number

    def get_name(self):
        return self.name

    def get_balance(self):
        return self._balance
if __name__ == "__main__":
    account = BankDetails("123456789", "Roshan", 1000)
    print("Account Number:", account.get_account_number())
    print("Name:", account.get_name())
    print("Balance:", account.get_balance())
    
#only private members are not accessible outside the class
#whereas protected members can be accessed by child classes and also outside the class
