'''class BankAccount:
    def __init__(self, accno, accname, balance):
        self.accno = accno
        self.accname = accname
        self.balance = balance
        
    def display(self):
        print(f"Account Number: {self.accno}")
        print(f"Account Holder Name: {self.accname}")
        print(f"Balance: {self.balance}")
        print("***********************")
        
    def deposit(self, amount):
        self.balance += amount
        print(f"Deposited: {amount}")
        
    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
            print(f"Withdrawn: {amount}")
        else:
            print("Insufficient balance")
            
    def check_balance(self):
        print(f"Current Balance: {self.balance}")

class SavingsAccount(BankAccount):
    def __init__(self, accno, accname, balance, interest_rate):
        super().__init__(accno, accname, balance)
        self.interest_rate = interest_rate

    def display(self):
        super().display()
        print(f"Interest Rate: {self.interest_rate}%")
        print("***********************")
    
    def calculate_interest(self):
        interest = (self.balance * self.interest_rate) / 100
        print(f"Interest earned: {interest}")
    
class CurrentAccount(BankAccount):
    def __init__(self, accno, accname, balance, overdraft_limit):
        super().__init__(accno, accname, balance)
        self.overdraft_limit = overdraft_limit

    def display(self):
        super().display()
        print(f"Overdraft Limit: {self.overdraft_limit}")
        print("*******************")
    
    def withdraw(self, amount):
        if self.balance + self.overdraft_limit >= amount:
            self.balance -= amount
            print(f"Withdrawn: {amount}")
        else:
            print("Withdrawal exceeds overdraft limit")
            
if __name__ == "__main__":
    acc1 = SavingsAccount(101, "Roshan", 10000, 5)
    acc2 = CurrentAccount(102, "Akhilesh", 20000, 5000)
    acc1.display()
    acc2.display()
    acc1.deposit(2000)
    acc1.withdraw(5000)
    acc1.check_balance()
    acc1.calculate_interest()
print("-------------------------------------------------------------------------------------------------")'''
class Product:
    def __init__(self, prdid, prdname, prdprice, prdqty):
        self.id = prdid
        self.name = prdname
        self.price = prdprice
        self.quantity = prdqty
        
    def display(self):
        print(f"Product ID: {self.id}")
        print(f"Product Name: {self.name}")
        print(f"Product Price: {self.price}")
        print(f"Product Quantity: {self.quantity}")
        print("***************")
        
    def bought_out(self, quantity):
        if self.quantity >= quantity:
            self.quantity -= quantity
            print(f"{quantity} units of {self.name} bought out.")
        else:
            print(f"Not enough stock of {self.name}. Only {self.quantity} units available.")
    
    def remaining_stock(self):
        print(f"Remaining stock of {self.name}: {self.quantity} units")

class Electronics(Product):
    def __init__(self, prdid, prdname, prdprice, prdqty, warranty_period,discount):
        super().__init__(prdid, prdname, prdprice, prdqty)#invoking base class constructor
        self.warranty_period = warranty_period
        self.discount = discount

    def display(self):
        super().display()
        print(f"Warranty Period: {self.warranty_period} years")
        print("***************")
    
    def apply_discount(self):
        discount_amount = (self.price * self.discount) / 100
        self.price -= discount_amount
        print(f"New Price after {self.discount}% discount: {self.price}")
        
class Grocery(Product):
    def __init__(self, prdid, prdname, prdprice, prdqty, expiry_date):
        super().__init__(prdid, prdname, prdprice, prdqty)
        self.expiry_date = expiry_date

    def display(self):
        super().display()
        print(f"Expiry Date: {self.expiry_date}")
        print("***************")

if __name__ == "__main__":
    P1=Electronics(101,"Laptop",50000,10,2,15)
    P2=Grocery(102,"Noodles",50,20,"2023-12-31")
    P1.display()
    P2.display()
    P1.bought_out(2)
    P1.remaining_stock()
    P1.apply_discount()
    P2.bought_out(5)
    P2.remaining_stock()
    
    
    
    