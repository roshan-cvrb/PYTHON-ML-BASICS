class Student:
    def __init__(self, name, score):
        self.name = name
        self.score = score
    def __str__(self):
        return f"Student Name: {self.name},Age :{self.score}"
    def __add__(self,other):
        return self.score + other.score
    def __len__(self):
        return len(self.name)
    def __eq__(self,other):
        return self.score==other.score

if __name__ == "__main__":
    s1 = Student("Roshan", 90)
    s2 = Student("Shaman", 90)
    print(s1)
    print(s2)
    print(f"Total Score: {s1 + s2}")
    print(f"Length of Name: {len(s1)}")
    print(f"Are scores equal? {s1 == s2}")