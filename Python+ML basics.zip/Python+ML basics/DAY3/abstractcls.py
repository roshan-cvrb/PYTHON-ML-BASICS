#Abstraction means hiding the implementation details and showing only the essential features of the object.
from abc import ABC, abstractmethod
class Vehicle(ABC):
    @abstractmethod
    def fuel_type(self):
        pass
class Car(Vehicle):
    def fuel_type(self):
        return "petrol or diesel"

class bike(Vehicle):
    def fuel_type(self):
        return "Battery"
    def own_fuel_type(self):
        return "Petrol or diesel"

if __name__ == "__main__":
    car = Car()
    bike = bike()
    print(f"Car uses: {car.fuel_type()}")
    print(f"Ebike uese: {bike.fuel_type()}")