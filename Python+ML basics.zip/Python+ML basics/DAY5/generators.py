def myfunc(max):
    count=1
    while(count<=max):
        yield count
        count+=1

for i in myfunc(5):
    print(i)