'''def require_acess(func):
    def wrapper(user,*args,**kwargs):
        if(user!="admin"):
            print("Access Denied!")
            return
        return func(user,*args,**kwargs)
        func()
    return wrapper

@require_acess
def func(user,user_id):
    print(f"the user id :{user_id} is deleted by {user}")
    
func('admin',101)
func('user',102)'''

def require_pass(func):
    def wrapper(s_name,s_mark,*args,**kwargs):
        if(s_mark<50):
            print("Access Denied!")
            return
        return func(s_name,s_mark,*args,**kwargs)
    return wrapper

@require_pass
def view_certificate(s_name,s_mark):
    print(f"Certificate granted to {s_name} with mark {s_mark}")

view_certificate("Roshan", 85)
view_certificate("Shaman", 35)



