from django.shortcuts import render
from django.http import HttpResponse
#def home(request):
    #return HttpResponse("Hello, Django!")
    
def home(request):
    context={'user_name':'Django'}
    return render(request,'home.html',context)

def about(request):
    return HttpResponse("This is a about page.")

def contact(request):
    return HttpResponse("This is a contact page.\n Contact No: 1234567890")

def calculator(request):
    return HttpResponse("This is a calculator page.")

def calculator(request):
    # Get parameters from URL: ?a=5&b=3&op=add
    a = request.GET.get('a')
    b = request.GET.get('b')
    op = request.GET.get('op')

    if a is None or b is None or op is None:
        return HttpResponse("Please provide 'a', 'b', and 'op' parameters. Example: ?a=5&b=3&op=add")

    try:
        a = float(a)
        b = float(b)
    except ValueError:
        return HttpResponse("Invalid numbers provided.")

    if op == 'add':
        result = a + b
    elif op == 'sub':
        result = a - b
    elif op == 'mul':
        result = a * b
    elif op == 'div':
        if b == 0:
            return HttpResponse("Division by zero error.")
        result = a / b
    else:
        return HttpResponse("Invalid operation. Use op=add, sub, mul, or div.")

    return HttpResponse(f"Result: {result}")
    