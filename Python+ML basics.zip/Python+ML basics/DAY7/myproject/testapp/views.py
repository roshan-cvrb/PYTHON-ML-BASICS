from django.shortcuts import render
from django.http import HttpResponse
from .forms import ContactForm

def home(request):
    return HttpResponse("Hello, Roshan!")

def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            message = form.cleaned_data['message']
            return HttpResponse(f"Hi {name} and message :{message}. We'll get back to you soon!")
    else:
        form = ContactForm()
    return render(request, 'contact.html', {'form': form})

