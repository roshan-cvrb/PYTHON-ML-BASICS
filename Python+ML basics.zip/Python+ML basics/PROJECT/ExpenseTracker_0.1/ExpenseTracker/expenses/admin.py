from django.contrib import admin

from .models import Expenses

admin.site.register(Expenses)
