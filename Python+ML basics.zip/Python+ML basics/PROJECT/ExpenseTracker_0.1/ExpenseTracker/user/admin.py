from django.contrib import admin
from .models import User_Data

admin.site.register(User_Data)