from pymongo import MongoClient
def  mongodb_connect(db,collection):
    try:
        client=MongoClient("mongodb://localhost:27017/")
        db=client[db]
        collection=db[collection]
        print("Connection Successful")
    except Exception as e:
        print(e)
    return collection

print(mongodb_connect("Training","Student"))
    