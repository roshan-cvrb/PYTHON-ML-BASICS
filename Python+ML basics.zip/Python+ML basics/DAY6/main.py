def get_weather(temperature):
    if temperature>30:
        return "It's hot outside."
    else:
        return "It's not that hot outside."