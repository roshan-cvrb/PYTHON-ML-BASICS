import streamlit as st
import requests

st.title("Fetching Data from Django")

response = requests.get("http://127.0.0.1:8000/api/students/")
if response.status_code == 200:
    data = response. json()
    st.write("Data from Django API:")
    st.write(data)
else:
    st.error("Failed to fetch data from Django API")