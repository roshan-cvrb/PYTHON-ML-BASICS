from django.shortcuts import render,redirect
from .models import Student

def create_student(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        age = request.POST.get('age')
        course = request.POST.get('course')
        student = Student(name=name, age=age, course=course)
        student.save()
        return redirect('student_list')
    return render(request, 'create_student.html')

def student_list(request):
    students = Student.objects.all()
    return render(request, 'student_list.html', {'students': students})

def update_student(request, student_id):
    student = Student.objects.get(id=student_id)
    if request.method == 'POST':
        student.name = request.POST.get('name')
        student.age = request.POST.get('age')
        student.course = request.POST.get('course')
        student.save()
        return redirect('student_list')
    return render(request, 'update_student.html', {'student': student})

def delete_student(request, student_id):
    student = Student.objects.get(id=student_id)
    student.delete()
    return redirect('student_list')



