from django.db import models
from mongoengine import Document, StringField, IntField

class Student (Document):
    name = StringField(required=True, max_length=100)
    age = IntField(required=True)
    course = StringField(required=True)
