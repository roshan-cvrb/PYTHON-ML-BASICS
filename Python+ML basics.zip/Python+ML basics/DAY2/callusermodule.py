from userpackage.firstmodule import add
from userpackage.secondmodule import is_perfect_number

'''def check(a,b,c):
    d=add(a,b,c)
    if is_perfect_number(d):
        print(f"{d} is a perfect number")
    else:
        print(f"{d} is not a perfect number")

if __name__=="__main__":
    a=int(input("Enter first number: "))
    b=int(input("Enter second number: "))
    c=int(input("Enter third number: "))
    check(a,b,c)'''

 
a=int(input("Enter first number: "))
b=int(input("Enter second number: "))
c=int(input("Enter third number: "))
sum=add(a,b,c)
if is_perfect_number(sum):
    print(f"{sum} is a perfect number")
else:
    print(f"{sum} is not a perfect number") 

    
    