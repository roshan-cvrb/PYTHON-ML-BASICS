def validate(username,password):
    if username == "admin" and password == 1234:
        print("Access granted")
    elif username == "admin" and password != 1234:
        print("Incorrect password")    
    else:
        print("Access denied")
if __name__=="__main__":
    username = input("Enter username: ")
    password = int(input("Enter password: "))
    validate(username,password)