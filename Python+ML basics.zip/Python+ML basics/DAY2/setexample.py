#set of items
numbers = {1, 2, 3, 4, 5}

#adding an item
numbers.add(6)


#removing an item
numbers.remove(2)


#discarding an item,removes an item if it exists and does nothing if it doesn't
numbers.discard(7)


#union of two sets
numbers2 = {5,6,7,8}
union_set= numbers.union(numbers2)


#intersection of two sets
intersection_set = numbers.intersection(numbers2)



#clear() -Removes all elements from the set
numbers.clear()


#Output
print("after union:",union_set)
print("after intersection:",intersection_set)
print("after clear:",numbers)