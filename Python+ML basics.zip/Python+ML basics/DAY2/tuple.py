#tuple
coordinates=(40.7128,-74.0060,40.7128)
#count-count occurences of a value
count_lattitude=coordinates.count(40.7128)
#index-returns the index of the first occurrence of a value
index_of_lattitude=coordinates.index(-74.0060)
print(count_lattitude)
print(index_of_lattitude)
#unpacking
x,y,z=coordinates
print(x)




