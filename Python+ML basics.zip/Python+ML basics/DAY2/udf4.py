def num_words(string):
    words=string.split()
    return len(words)

if __name__=="__main__":
    string=input()
    print(num_words(string))