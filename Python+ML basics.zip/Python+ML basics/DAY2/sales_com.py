sid=input()
sval=float(input())
com=0
if(sval<=10000):
    com=0
elif(sval>10000 and sval<=50000):
    com=(0.1*sval)
elif(sval>50000 and sval<=100000):
    com=0.15*sval    
else:
    com=0.2*sval
print("%.2f" % com)
print(f"{sid} {com:.2f}")    