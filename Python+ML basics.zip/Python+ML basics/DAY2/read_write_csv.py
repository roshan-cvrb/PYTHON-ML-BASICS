import csv
data=[
    ["Alice", 25, "A"],
    ["Bob", 30, "B"],
    ["Charlie", 35, "C"]
]

with open("students.csv", "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["Name", "Age", "Grade"])
    writer.writerows(data)
    
try:
    with open("students.csv", "r") as file:
        reader = csv.reader(file)
        for row in reader:
            print(row)
except FileNotFoundError:
    print("File not found.")