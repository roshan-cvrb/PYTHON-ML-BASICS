
product = {
    101: {'product_name': 'apple','product_quantity': 10},
    102: {'product_name': 'banana','product_quantity': 20},
    103: {'product_name': 'orange','product_quantity': 15}
}
#1.get
product_101=product.get(101)

#2.keys
keys=product.keys()


#3.values
values=product.values()



# 4.update()-Updating a value
product.update({4: {'product_name': 'grape','product_quantity': 25}})

#5.pop()
removed_product = product.pop(101)

#popItem()
last_item = product.popitem()



    

# Clearing the dictionary
#product.clear()


#Output
print(product_101)
print(keys)
print(values)
print(removed_product)
print(last_item)
print(product)

for key, value in product.items():
    if value['product_name'] == 'orange':
        print(f"Product found: {key} - {value}")
        break