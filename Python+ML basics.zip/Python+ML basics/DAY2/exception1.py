try:
    a=int(input("Enter number: "))
except ValueError:
    print("Invalid input. Please enter a number.")
else:
    print("square is",a*a)