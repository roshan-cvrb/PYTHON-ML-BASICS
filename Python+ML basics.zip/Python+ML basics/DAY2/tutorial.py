#employee db
employees = [
    {"name": "Roshan Balaji","email": "Roshan.Balaji@alti.com"},
    {"name": "Gowtham Natraj","email": "gowtham.Natraj@alti.com"},
    {"name": "Shaman Kanapathy","email": "Shaman.Kanapathy@balti.com"}
]
 
#validation function
def validation(record):
    name = record["name"].strip()
    email = record["email"].lower()
 
    if email.find("@alti.com")==-1:
        return f"Invalid domain for the email address of {name}"
    if not email.startswith(name[0].lower()):
        return f"Invalid username for the email address of {name}"
    else:
        return f"Valid email address for the employee {name}"
 
#username generation
def generate_username(record):
    name = record["name"].strip()
    splitted_name = (name.lower()).split()
 
    username = splitted_name[0]+'.'+splitted_name[1]
    return f"The username for {name} is : {username}"
 
for emp in employees:
    print(validation(emp),"\n",generate_username(emp))