#UDF for finding a number is perfect number or not->procedural model
'''def is_perfect_number(n):
    sum=0
    for i in range(1,n):
        if n%i==0:
            sum+=i
    if sum==n:
        return True
    else:
        return False
if __name__=="__main__":
    num=int(input())
    if is_perfect_number(num):
        print(f"{num} is a perfect number")
    else:
        print(f"{num} is not a perfect number")'''
        
#default arguments-if argument is not passed, it takes the default value
'''def add(a,b=1):
    return a+b
if __name__=="__main__":
    print(add(5,2))
    print(add(5)) #default value of b is 1
    print(add(y=4))'''
    
    





    
        