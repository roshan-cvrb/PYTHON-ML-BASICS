#write
with open("employees.txt", "w") as f:
    f.write("ID,Name,Department,Salary\n")
    f.write("1,John Doe,HR,50000\n")
    f.write("2,Jane Smith,IT,60000\n")
    f.write("3,Emily Davis,Finance,70000\n")
print("File written successfully")

#read
try:
    with open("employees.txt", "r") as f:
        for line in f:
            print(line.strip())
except FileNotFoundError:
    print("File read successfully")
    
#append
with open("employees.txt", "a") as f:
    f.write("4,Michael Brown,Marketing,55000\n")
print("File appended successfully")

#handling exceptions in file handling
try:
    with open("non_existent_file.txt", "r") as f:
        data = f.read()
        print(data)
except FileNotFoundError:
    print("File not found. Please check the file name and path.")