#write
f=open("test.txt","w")
f.write("hello world\n")
print("File written successfully")
f.close()

#append
f=open("test.txt","a")
f.write("This is Python Programming\n")
print("File appended successfully")
f.close()

#read
f=open("test.txt","r")
data=f.read()
print(data)
print("File read successfully")
f.close()