def calculate_bill(price,quantity,discount=0):
    total=price*quantity
    total_after_discount=total-(total*discount/100)
    return total_after_discount
if __name__=="__main__":
    bill=calculate_bill(price=100,quantity=5,discount=25)
    print("Total bill after discount:",bill)