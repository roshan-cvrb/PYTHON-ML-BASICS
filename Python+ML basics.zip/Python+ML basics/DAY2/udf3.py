#kwargs
'''def show_details(**kwargs):
    for key, value in kwargs.items():
        print(f"{key}: {value}")
show_details(name="John", age=30, city="New York")
show_details(name="John", age=30, city="New York", country="USA")'''

'''module: collection of
'''


